package com.flowforge.eligibility.executor;

import com.flowforge.eligibility.registry.CheckRegistry;
import com.flowforge.eligibility.registry.EligibilityCheck;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.CheckResultStatus;
import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.observability.WorkflowLogger;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.*;

/**
 * Executes all eligibility checks for a workflow instance according to the
 * mode defined in WorkflowDefinition (sequential | parallel | waterfall).
 *
 * Results are returned as an EligibilityResult containing per-check outcomes.
 */
@Service
@RequiredArgsConstructor
public class EligibilityExecutor {

    private static final Logger log = LogManager.getLogger(EligibilityExecutor.class);

    private final CheckRegistry checkRegistry;
    private final WorkflowLogger workflowLogger;

    public EligibilityResult execute(
            WorkflowDefinition definition,
            EligibilityCheck.WorkflowContext context) {

        WorkflowDefinition.EligibilityConfig config = definition.getEligibility();
        String mode = config.getMode() != null ? config.getMode() : "sequential";

        log.info("[{}] Starting eligibility execution: mode={}, checks={}",
            context.getInstanceId(), mode,
            config.getChecks().stream().map(WorkflowDefinition.CheckConfig::getCheckId).toList());

        return switch (mode.toLowerCase()) {
            case "parallel"   -> runParallel(config, context);
            case "waterfall"  -> runWaterfall(config, context);
            default           -> runSequential(config, context);  // sequential (fail-fast)
        };
    }

    // ── Sequential: ordered, fail-fast on HARD failures ──────────────────────

    private EligibilityResult runSequential(
            WorkflowDefinition.EligibilityConfig config,
            EligibilityCheck.WorkflowContext context) {

        List<CheckOutcome> outcomes = new ArrayList<>();
        boolean overallPass = true;
        boolean requiresReview = false;

        for (WorkflowDefinition.CheckConfig checkConfig : config.getChecks()) {
            CheckOutcome outcome = runSingleCheck(checkConfig, context);
            outcomes.add(outcome);

            if (outcome.getStatus() == CheckResultStatus.FAIL) {
                overallPass = false;
                if (checkConfig.getOverridePolicy() == OverridePolicy.HARD) {
                    log.warn("[{}] HARD FAIL on check [{}] — stopping eligibility",
                        context.getInstanceId(), checkConfig.getCheckId());
                    break;  // hard fail → stop immediately
                }
            } else if (outcome.getStatus() == CheckResultStatus.PENDING_REVIEW) {
                requiresReview = true;
            }
        }

        return buildResult(outcomes, overallPass, requiresReview, context);
    }

    // ── Waterfall: stop on first failure of any kind ──────────────────────────

    private EligibilityResult runWaterfall(
            WorkflowDefinition.EligibilityConfig config,
            EligibilityCheck.WorkflowContext context) {

        List<CheckOutcome> outcomes = new ArrayList<>();

        for (WorkflowDefinition.CheckConfig checkConfig : config.getChecks()) {
            CheckOutcome outcome = runSingleCheck(checkConfig, context);
            outcomes.add(outcome);

            if (outcome.getStatus() == CheckResultStatus.FAIL ||
                outcome.getStatus() == CheckResultStatus.PENDING_REVIEW) {
                log.info("[{}] Waterfall stopping at check [{}] with status={}",
                    context.getInstanceId(), checkConfig.getCheckId(), outcome.getStatus());
                break;
            }
        }

        boolean pass = outcomes.stream().allMatch(o -> o.getStatus() == CheckResultStatus.PASS);
        boolean review = outcomes.stream().anyMatch(o -> o.getStatus() == CheckResultStatus.PENDING_REVIEW);
        return buildResult(outcomes, pass, review, context);
    }

    // ── Parallel: run all checks concurrently, collect all results ────────────

    private EligibilityResult runParallel(
            WorkflowDefinition.EligibilityConfig config,
            EligibilityCheck.WorkflowContext context) {

        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor(); // JDK 21 virtual threads
        List<Future<CheckOutcome>> futures = new ArrayList<>();

        for (WorkflowDefinition.CheckConfig checkConfig : config.getChecks()) {
            futures.add(executor.submit(() -> runSingleCheck(checkConfig, context)));
        }

        List<CheckOutcome> outcomes = new ArrayList<>();
        for (Future<CheckOutcome> future : futures) {
            try {
                outcomes.add(future.get(30, TimeUnit.SECONDS));
            } catch (Exception e) {
                log.error("[{}] Parallel check execution error: {}", context.getInstanceId(), e.getMessage());
                outcomes.add(CheckOutcome.builder()
                    .checkId("UNKNOWN")
                    .status(CheckResultStatus.FAIL)
                    .reason("Check execution error: " + e.getMessage())
                    .build());
            }
        }
        executor.shutdown();

        boolean pass = outcomes.stream().allMatch(o -> o.getStatus() == CheckResultStatus.PASS);
        boolean review = outcomes.stream().anyMatch(o -> o.getStatus() == CheckResultStatus.PENDING_REVIEW);
        return buildResult(outcomes, pass, review, context);
    }

    // ── Single check runner ───────────────────────────────────────────────────

    private CheckOutcome runSingleCheck(
            WorkflowDefinition.CheckConfig checkConfig,
            EligibilityCheck.WorkflowContext context) {

        String checkId = checkConfig.getCheckId();
        Map<String, Object> params = checkConfig.getParams() != null ? checkConfig.getParams() : Map.of();

        log.debug("[{}] Executing check: {}", context.getInstanceId(), checkId);

        try {
            EligibilityCheck check = checkRegistry.getById(checkId);
            EligibilityCheck.CheckResult result = check.execute(context, params);

            workflowLogger.logCheckResult(context.getInstanceId(), checkId, result);

            return CheckOutcome.builder()
                .checkId(checkId)
                .checkName(check.getName())
                .status(result.getStatus())
                .reason(result.getReason())
                .metadata(result.getMetadata())
                .durationMs(result.getDurationMs())
                .overridePolicy(checkConfig.getOverridePolicy())
                .build();

        } catch (Exception e) {
            log.error("[{}] Check [{}] threw exception: {}", context.getInstanceId(), checkId, e.getMessage(), e);
            return CheckOutcome.builder()
                .checkId(checkId)
                .status(CheckResultStatus.FAIL)
                .reason("Check threw exception: " + e.getMessage())
                .overridePolicy(checkConfig.getOverridePolicy())
                .build();
        }
    }

    private EligibilityResult buildResult(
            List<CheckOutcome> outcomes, boolean pass, boolean requiresReview,
            EligibilityCheck.WorkflowContext context) {

        EligibilityResult result = new EligibilityResult();
        result.setInstanceId(context.getInstanceId());
        result.setOutcomes(outcomes);
        result.setEligible(pass && !requiresReview);
        result.setRequiresReview(requiresReview);

        log.info("[{}] Eligibility complete: eligible={} requiresReview={} checks={}",
            context.getInstanceId(), result.isEligible(), result.isRequiresReview(), outcomes.size());

        return result;
    }

    // ── Result DTOs ───────────────────────────────────────────────────────────

    @Data
    public static class EligibilityResult {
        private String instanceId;
        private List<CheckOutcome> outcomes;
        private boolean eligible;
        private boolean requiresReview;

        public boolean isHardFailed() {
            return outcomes.stream().anyMatch(o ->
                o.getStatus() == CheckResultStatus.FAIL &&
                o.getOverridePolicy() == OverridePolicy.HARD);
        }
    }

    @Data
    @lombok.Builder
    public static class CheckOutcome {
        private String checkId;
        private String checkName;
        private CheckResultStatus status;
        private String reason;
        private Map<String, Object> metadata;
        private Long durationMs;
        private OverridePolicy overridePolicy;
    }
}
