# ⚡ FlowForge — Generic Workflow Engine

A production-ready, pluggable workflow engine built with **JDK 21**, **Spring Boot 3.3**, **MongoDB**, **Oracle**, and **RabbitMQ**. Includes a full test UI for configuring rules and tracking workflow instances.

---

## Architecture Decision Records

| Concern | Technology | Why |
|---|---|---|
| Workflow definitions | **MongoDB** | Schema-flexible — each workflow type has a different shape. New types added without migrations. |
| Workflow instances + audit | **Oracle** | ACID guarantees — state transitions and audit trail must be consistent and atomic. |
| Async process steps | **RabbitMQ** | Durable messaging with exchange/routing/reply-queue pattern. Native correlation ID support. |
| Sync process steps | **REST (WebClient)** | Standard HTTP with retry + circuit breaker via Reactor. |
| Logging / observability | **Log4j2** | Structured JSON logs + MDC for per-instance correlation. Separate audit log file. |
| JVM | **JDK 21 Virtual Threads** | Used for parallel eligibility checks (`Executors.newVirtualThreadPerTaskExecutor()`). |
| Mock services | **Python / Flask** | Lightweight simulation of downstream REST APIs for local testing. |

---

## Project Structure

```
flowforge/
├── workflow-engine/               # Spring Boot application
│   ├── src/main/java/com/flowforge/
│   │   ├── FlowForgeApplication.java
│   │   ├── engine/
│   │   │   ├── core/WorkflowEngine.java        # Main orchestrator
│   │   │   ├── registry/                       # JPA + Mongo repositories
│   │   │   └── statemachine/StateMachine.java  # Transition validator
│   │   ├── eligibility/
│   │   │   ├── registry/EligibilityCheck.java  # Plug-in interface
│   │   │   ├── registry/CheckRegistry.java     # Auto-discovery
│   │   │   ├── checks/BuiltInChecks.java       # 4 built-in checks
│   │   │   └── executor/EligibilityExecutor.java
│   │   ├── process/
│   │   │   ├── rest/RestProcessExecutor.java   # Sync HTTP steps
│   │   │   └── rabbitmq/RabbitMQProcessExecutor.java
│   │   ├── model/domain/                       # JPA + MongoDB entities
│   │   ├── config/                             # Spring config beans
│   │   ├── api/controller/WorkflowController.java
│   │   └── observability/WorkflowLogger.java   # Structured Log4j2
│   └── src/main/resources/
│       ├── application.yml
│       └── log4j2.xml
├── ui/index.html                  # Single-page test UI
├── docker/
│   ├── mock-services.py           # Python Flask mock APIs
│   ├── Dockerfile.mock
│   └── nginx.conf
├── docker-compose.yml
└── README.md
```

---

## Quick Start

### Prerequisites
- Docker & Docker Compose
- JDK 21 (for local dev only)

### 1. Start the full stack

```bash
docker-compose up --build
```

This starts:
| Service | URL |
|---|---|
| FlowForge Engine API | http://localhost:8080/api |
| Swagger UI | http://localhost:8080/api/swagger-ui.html |
| **Test UI** | **http://localhost:3000** |
| RabbitMQ Management | http://localhost:15672 (flowforge / flowforge123) |
| MongoDB | mongodb://localhost:27017/flowforge |
| Oracle | jdbc:oracle:thin:@localhost:1521/FREEPDB1 |
| Mock Services | http://localhost:8081 |

### 2. Open the Test UI
Navigate to **http://localhost:3000** in your browser.

---

## Using the Test UI

### Dashboard
- Live metrics: total today, approved, rejected, pending review, active
- Recent instance list with status badges
- Pending review queue with quick-approve buttons
- Auto-refreshes every 5 seconds

### Trigger Workflow
1. Select workflow type (Loan Application, Wire Transfer, Account Opening)
2. Enter entity ID (or click 🎲 to randomise)
3. Edit the input data JSON (pre-filled with sensible defaults)
4. Click **Start Workflow**
5. Watch the live status poll and log output

### Instances
- Filter by type, status
- Paginated list with duration and current step
- Click any row to open the detail modal with:
  - Overview, Eligibility Results, Audit Trail, Context JSON tabs
  - Manual cancel button
  - Pending Review → inline approve/reject

### Manual Override
- Lists all PENDING_REVIEW instances
- Shows eligibility check breakdown per instance
- Approve or Reject with reason and reviewer name

### Workflow Definitions (MongoDB)
- View all active workflow type definitions
- Create new / edit existing definitions via JSON editor
- Live validation — saves directly to MongoDB

### Check Registry
- Lists all registered `EligibilityCheck` beans discovered at startup
- Shows check ID, name, class, and cacheability
- Includes code snippet showing how to implement a new check

### Raw API Console
- Full HTTP client for direct engine calls
- Quick presets for common operations
- Response with status code and duration

---

## Adding a New Eligibility Check

1. **Implement the interface** — that's it:

```java
@Component
public class SanctionsCheck implements EligibilityCheck {

    @Override
    public String getCheckId() { return "SANCTIONS_CLEAR"; }

    @Override
    public String getName() { return "Sanctions Screening"; }

    @Override
    public boolean isCacheable() { return false; }

    @Override
    public CheckResult execute(WorkflowContext ctx, Map<String, Object> params) {
        boolean clear = callSanctionsApi(ctx.getEntityId());
        return CheckResult.builder()
            .status(clear ? CheckResultStatus.PASS : CheckResultStatus.FAIL)
            .reason(clear ? "Entity is sanctions-clear" : "Entity found on sanctions list")
            .build();
    }
}
```

2. The `CheckRegistry` discovers it at startup — no other changes needed.

3. Reference it in a workflow definition:

```json
{
  "checkId": "SANCTIONS_CLEAR",
  "overridePolicy": "HARD",
  "params": {}
}
```

---

## Adding a New Workflow Type

Via the Test UI (Definitions tab) or API:

```bash
curl -X POST http://localhost:8080/api/workflows/definitions \
  -H "Content-Type: application/json" \
  -d '{
    "workflowType": "MORTGAGE_APPLICATION",
    "version": "1.0.0",
    "description": "Mortgage application workflow",
    "active": true,
    "eligibility": {
      "mode": "sequential",
      "checks": [
        { "checkId": "KYC_VERIFIED", "overridePolicy": "HARD", "params": {} },
        { "checkId": "CREDIT_SCORE_THRESHOLD", "overridePolicy": "SOFT", "params": { "min_score": 700 } }
      ]
    },
    "processes": [
      {
        "id": "property_valuation",
        "type": "RABBITMQ",
        "exchange": "flowforge.process.exchange",
        "routingKey": "valuation.request",
        "replyQueue": "flowforge.reply.queue",
        "asyncTimeoutMs": 60000
      }
    ],
    "statusTransitions": {
      "initial": "INITIATED",
      "terminal": ["APPROVED", "REJECTED", "CANCELLED"]
    }
  }'
```

---

## API Reference

| Method | Path | Description |
|---|---|---|
| `POST` | `/workflows/{type}/start` | Start a new workflow instance |
| `GET` | `/workflows/{id}` | Get instance by ID |
| `GET` | `/workflows/{id}/audit` | Get full audit trail |
| `GET` | `/workflows` | List instances (type, status, entityId filters) |
| `POST` | `/workflows/{id}/override` | Approve or reject PENDING_REVIEW instance |
| `POST` | `/workflows/{id}/cancel` | Cancel a workflow instance |
| `GET` | `/workflows/stats/dashboard` | Dashboard statistics |
| `GET` | `/workflows/checks/registry` | List all registered checks |
| `GET` | `/workflows/definitions` | List active workflow definitions |
| `POST` | `/workflows/definitions` | Create or update a definition |

---

## Observability

### Log Files (inside container)
| File | Content |
|---|---|
| `/var/log/flowforge/flowforge.json` | All logs, structured JSON for ELK / Loki |
| `/var/log/flowforge/flowforge-audit.log` | Audit events only (state transitions, check results) |
| `/var/log/flowforge/flowforge-error.log` | Errors only |

### MDC Fields
Every log line emitted during workflow execution carries:

| Field | Value |
|---|---|
| `instanceId` | Workflow instance UUID |
| `workflowId` | Workflow type name |
| `stepId` | Current process step |
| `traceId` | Same as instanceId (extend with OTEL for distributed tracing) |

### Metrics (Prometheus)
Available at `http://localhost:8080/api/actuator/prometheus`

---

## Running Tests

```bash
cd workflow-engine
./gradlew test
```

Tests use H2 (in-memory) for Oracle and Flapdoodle embedded MongoDB, so no infrastructure needed.

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `MONGO_URI` | `mongodb://mongo:27017/flowforge` | MongoDB connection string |
| `ORACLE_URL` | `jdbc:oracle:thin:@oracle:1521/FREEPDB1` | Oracle JDBC URL |
| `ORACLE_USER` | `flowforge` | Oracle username |
| `ORACLE_PASS` | `flowforge123` | Oracle password |
| `RABBITMQ_HOST` | `rabbitmq` | RabbitMQ hostname |
| `RABBITMQ_USER` | `flowforge` | RabbitMQ username |
| `RABBITMQ_PASS` | `flowforge123` | RabbitMQ password |
| `LOG_DIR` | `/var/log/flowforge` | Log output directory |
| `APP_ENV` | `local` | Environment tag in JSON logs |
