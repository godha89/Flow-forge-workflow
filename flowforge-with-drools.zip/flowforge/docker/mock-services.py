"""
FlowForge Mock Services
Simulates downstream REST APIs called by workflow process steps.
Used for local development and UI testing.
"""
import json
import random
import time
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s - %(message)s'
)
log = logging.getLogger("mock-services")

app = Flask(__name__)
CORS(app)


def simulated_delay(min_ms=50, max_ms=300):
    """Simulate realistic network latency"""
    time.sleep(random.uniform(min_ms, max_ms) / 1000)


# ── Credit Bureau ─────────────────────────────────────────────────────────────

@app.route('/credit/pull', methods=['POST'])
def credit_pull():
    body = request.get_json(force=True) or {}
    simulated_delay(100, 400)

    entity_id = body.get('entityId', 'unknown')
    # Deterministic score based on entity hash for reproducibility
    score = 550 + (hash(entity_id) % 300)  # range 550–850

    log.info(f"Credit pull: entityId={entity_id} score={score}")
    return jsonify({
        "status": "SUCCESS",
        "entityId": entity_id,
        "creditScore": score,
        "bureau": "EQUIFAX",
        "reportDate": "2025-01-01",
        "factors": ["payment_history", "utilization"]
    })


# ── Risk Assessment ───────────────────────────────────────────────────────────

@app.route('/risk/evaluate', methods=['POST'])
def risk_evaluate():
    body = request.get_json(force=True) or {}
    simulated_delay(80, 250)

    credit_score = body.get('creditScore', 650)
    # Higher credit score → lower risk
    risk_score = round(max(0.05, min(0.95, 1.0 - (credit_score / 1000))), 3)

    log.info(f"Risk eval: entityId={body.get('entityId')} riskScore={risk_score}")
    return jsonify({
        "status": "SUCCESS",
        "entityId": body.get('entityId'),
        "riskScore": risk_score,
        "riskBand": "LOW" if risk_score < 0.3 else "MEDIUM" if risk_score < 0.6 else "HIGH",
        "modelVersion": "v2.1"
    })


# ── Wire Transfer ─────────────────────────────────────────────────────────────

@app.route('/transfers/execute', methods=['POST'])
def execute_transfer():
    body = request.get_json(force=True) or {}
    simulated_delay(200, 600)

    log.info(f"Transfer: instanceId={body.get('workflowInstanceId')} entityId={body.get('entityId')}")
    return jsonify({
        "status": "SUCCESS",
        "transactionId": f"TXN-{random.randint(100000, 999999)}",
        "entityId": body.get('entityId'),
        "executedAt": "2025-01-01T00:00:00Z"
    })


# ── Account Creation ──────────────────────────────────────────────────────────

@app.route('/accounts/create', methods=['POST'])
def create_account():
    body = request.get_json(force=True) or {}
    simulated_delay(150, 400)

    account_id = f"ACC-{random.randint(10000000, 99999999)}"
    log.info(f"Account creation: entityId={body.get('entityId')} accountId={account_id}")
    return jsonify({
        "status": "SUCCESS",
        "accountId": account_id,
        "entityId": body.get('entityId'),
        "accountType": "SAVINGS",
        "createdAt": "2025-01-01T00:00:00Z"
    })


# ── Decision Engine ───────────────────────────────────────────────────────────

@app.route('/decisions/evaluate', methods=['POST'])
def evaluate_decision():
    body = request.get_json(force=True) or {}
    simulated_delay(100, 300)

    credit_score = body.get('creditScore', 0)
    risk_score = body.get('riskScore', 1.0)

    approved = credit_score >= 650 and risk_score < 0.5
    log.info(f"Decision: entityId={body.get('entityId')} approved={approved}")
    return jsonify({
        "status": "SUCCESS",
        "decision": "APPROVED" if approved else "DECLINED",
        "reason": "Meets criteria" if approved else "Does not meet risk criteria",
        "decisionId": f"DEC-{random.randint(10000, 99999)}"
    })


# ── Health ────────────────────────────────────────────────────────────────────

@app.route('/health', methods=['GET'])
def health():
    return jsonify({"status": "UP", "service": "mock-services"})


if __name__ == '__main__':
    log.info("FlowForge Mock Services starting on port 8081")
    app.run(host='0.0.0.0', port=8081, debug=False)
