package com.flowforge;

import com.flowforge.eligibility.executor.EligibilityExecutor;
import com.flowforge.eligibility.registry.CheckRegistry;
import com.flowforge.eligibility.registry.EligibilityCheck;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.CheckResultStatus;
import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.observability.WorkflowLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class EligibilityExecutorTest {

    @Mock CheckRegistry checkRegistry;
    @Mock WorkflowLogger workflowLogger;

    EligibilityExecutor executor;

    @BeforeEach
    void setUp() {
        executor = new EligibilityExecutor(checkRegistry, workflowLogger);
    }

    private EligibilityCheck.WorkflowContext ctx(String instanceId) {
        return EligibilityCheck.WorkflowContext.builder()
            .instanceId(instanceId)
            .workflowType("LOAN_APPLICATION")
            .entityId("ent-001")
            .entityType("CUSTOMER")
            .entityData(Map.of("kycStatus", "VERIFIED", "creditScore", 700, "riskScore", 0.2))
            .contextData(Map.of())
            .inputData(Map.of())
            .build();
    }

    private WorkflowDefinition.CheckConfig checkConfig(String id, OverridePolicy policy) {
        WorkflowDefinition.CheckConfig cfg = new WorkflowDefinition.CheckConfig();
        cfg.setCheckId(id);
        cfg.setOverridePolicy(policy);
        cfg.setParams(Map.of());
        return cfg;
    }

    private EligibilityCheck mockCheck(String id, CheckResultStatus status) {
        EligibilityCheck check = mock(EligibilityCheck.class);
        when(check.getCheckId()).thenReturn(id);
        when(check.getName()).thenReturn(id);
        when(check.execute(any(), any())).thenReturn(
            EligibilityCheck.CheckResult.builder().status(status).reason("test").durationMs(10).build());
        return check;
    }

    @Test
    void sequential_allPass_returnsEligible() {
        EligibilityCheck kycCheck = mockCheck("KYC_VERIFIED", CheckResultStatus.PASS);
        EligibilityCheck creditCheck = mockCheck("CREDIT_SCORE_THRESHOLD", CheckResultStatus.PASS);

        when(checkRegistry.getById("KYC_VERIFIED")).thenReturn(kycCheck);
        when(checkRegistry.getById("CREDIT_SCORE_THRESHOLD")).thenReturn(creditCheck);

        WorkflowDefinition.EligibilityConfig config = new WorkflowDefinition.EligibilityConfig();
        config.setMode("sequential");
        config.setChecks(List.of(
            checkConfig("KYC_VERIFIED", OverridePolicy.HARD),
            checkConfig("CREDIT_SCORE_THRESHOLD", OverridePolicy.SOFT)
        ));

        WorkflowDefinition def = new WorkflowDefinition();
        def.setEligibility(config);

        EligibilityExecutor.EligibilityResult result = executor.execute(def, ctx("inst-001"));

        assertThat(result.isEligible()).isTrue();
        assertThat(result.isRequiresReview()).isFalse();
        assertThat(result.getOutcomes()).hasSize(2);
    }

    @Test
    void sequential_hardFail_stopsExecution() {
        EligibilityCheck kycCheck = mockCheck("KYC_VERIFIED", CheckResultStatus.FAIL);
        EligibilityCheck creditCheck = mockCheck("CREDIT_SCORE_THRESHOLD", CheckResultStatus.PASS);

        when(checkRegistry.getById("KYC_VERIFIED")).thenReturn(kycCheck);
        // credit should NEVER be called after hard fail
        when(checkRegistry.getById("CREDIT_SCORE_THRESHOLD")).thenReturn(creditCheck);

        WorkflowDefinition.EligibilityConfig config = new WorkflowDefinition.EligibilityConfig();
        config.setMode("sequential");
        config.setChecks(List.of(
            checkConfig("KYC_VERIFIED", OverridePolicy.HARD),
            checkConfig("CREDIT_SCORE_THRESHOLD", OverridePolicy.SOFT)
        ));

        WorkflowDefinition def = new WorkflowDefinition();
        def.setEligibility(config);

        EligibilityExecutor.EligibilityResult result = executor.execute(def, ctx("inst-002"));

        assertThat(result.isEligible()).isFalse();
        assertThat(result.isHardFailed()).isTrue();
        // Only 1 check should have been executed (stopped at KYC)
        assertThat(result.getOutcomes()).hasSize(1);
        verify(creditCheck, never()).execute(any(), any());
    }

    @Test
    void pendingReview_setsRequiresReview() {
        EligibilityCheck riskCheck = mockCheck("RISK_SCORE_LOW", CheckResultStatus.PENDING_REVIEW);
        when(checkRegistry.getById("RISK_SCORE_LOW")).thenReturn(riskCheck);

        WorkflowDefinition.EligibilityConfig config = new WorkflowDefinition.EligibilityConfig();
        config.setMode("sequential");
        config.setChecks(List.of(checkConfig("RISK_SCORE_LOW", OverridePolicy.SOFT)));

        WorkflowDefinition def = new WorkflowDefinition();
        def.setEligibility(config);

        EligibilityExecutor.EligibilityResult result = executor.execute(def, ctx("inst-003"));

        assertThat(result.isRequiresReview()).isTrue();
        assertThat(result.isEligible()).isFalse();
    }

    @Test
    void parallel_allPass_returnsEligible() {
        EligibilityCheck c1 = mockCheck("CHECK_A", CheckResultStatus.PASS);
        EligibilityCheck c2 = mockCheck("CHECK_B", CheckResultStatus.PASS);
        EligibilityCheck c3 = mockCheck("CHECK_C", CheckResultStatus.PASS);

        when(checkRegistry.getById("CHECK_A")).thenReturn(c1);
        when(checkRegistry.getById("CHECK_B")).thenReturn(c2);
        when(checkRegistry.getById("CHECK_C")).thenReturn(c3);

        WorkflowDefinition.EligibilityConfig config = new WorkflowDefinition.EligibilityConfig();
        config.setMode("parallel");
        config.setChecks(List.of(
            checkConfig("CHECK_A", OverridePolicy.SOFT),
            checkConfig("CHECK_B", OverridePolicy.SOFT),
            checkConfig("CHECK_C", OverridePolicy.SOFT)
        ));

        WorkflowDefinition def = new WorkflowDefinition();
        def.setEligibility(config);

        EligibilityExecutor.EligibilityResult result = executor.execute(def, ctx("inst-004"));

        assertThat(result.isEligible()).isTrue();
        assertThat(result.getOutcomes()).hasSize(3);
    }
}
