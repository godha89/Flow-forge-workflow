package com.flowforge.drools;

import com.flowforge.config.DroolsConfig;
import com.flowforge.eligibility.drools.DroolsEligibilityService;
import com.flowforge.eligibility.executor.EligibilityExecutor.EligibilityResult;
import com.flowforge.eligibility.registry.EligibilityCheck.WorkflowContext;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.observability.WorkflowLogger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Drools rule tests — each test validates a single business rule.
 *
 * Reading these tests tells you exactly what the rules enforce.
 * No Drools knowledge needed — tests read like plain English.
 */
@SpringBootTest(classes = {DroolsConfig.class, DroolsEligibilityService.class})
class DroolsEligibilityTest {

    @Autowired
    DroolsEligibilityService droolsService;

    @MockBean
    WorkflowLogger workflowLogger;

    // A simple loan application definition with standard thresholds
    WorkflowDefinition loanDefinition;

    @BeforeEach
    void setUp() {
        loanDefinition = new WorkflowDefinition();
        loanDefinition.setWorkflowType("LOAN_APPLICATION");

        WorkflowDefinition.EligibilityConfig elig = new WorkflowDefinition.EligibilityConfig();
        elig.setMode("drools");
        elig.setChecks(List.of(
            checkConfig("CREDIT_SCORE_THRESHOLD", Map.of("min_score", 650)),
            checkConfig("RISK_SCORE_LOW",         Map.of("threshold", 0.4)),
            checkConfig("BALANCE_SUFFICIENT",     Map.of("min_balance", 1000.0))
        ));
        loanDefinition.setEligibility(elig);
    }

    // ── KYC Rules ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("KYC verified → passes")
    void kycVerified_passes() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 700,
            "riskScore", 0.2,
            "balance", 5000.0
        ));
        assertThat(result.isEligible()).isTrue();
    }

    @Test
    @DisplayName("KYC not verified → hard fail")
    void kycNotVerified_hardFail() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "PENDING",
            "creditScore", 750,
            "riskScore", 0.1,
            "balance", 10000.0
        ));
        assertThat(result.isEligible()).isFalse();
        assertThat(result.isRequiresReview()).isFalse();
        assertThat(result.getOutcomes().get(0).getOverridePolicy()).isEqualTo(OverridePolicy.HARD);
        assertThat(result.getOutcomes().get(0).getReason()).contains("PENDING");
    }

    @Test
    @DisplayName("KYC missing → hard fail")
    void kycMissing_hardFail() {
        EligibilityResult result = evaluate(Map.of(
            "creditScore", 700,
            "riskScore", 0.2,
            "balance", 5000.0
            // no kycStatus
        ));
        assertThat(result.isEligible()).isFalse();
        assertThat(result.getOutcomes().get(0).getOverridePolicy()).isEqualTo(OverridePolicy.HARD);
    }

    // ── Credit Score Rules ────────────────────────────────────────────────────

    @Test
    @DisplayName("Credit score above minimum → passes")
    void creditScoreAboveMin_passes() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 720,
            "riskScore", 0.2,
            "balance", 5000.0
        ));
        assertThat(result.isEligible()).isTrue();
    }

    @Test
    @DisplayName("Credit score below minimum → soft fail")
    void creditScoreBelowMin_softFail() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 580,          // below 650
            "riskScore", 0.2,
            "balance", 5000.0
        ));
        assertThat(result.isEligible()).isFalse();
        assertThat(result.getOutcomes().get(0).getOverridePolicy()).isEqualTo(OverridePolicy.SOFT);
        assertThat(result.getOutcomes().get(0).getReason()).contains("580").contains("650");
    }

    @Test
    @DisplayName("Credit score borderline (within 50 of min) → pending review")
    void creditScoreBorderline_pendingReview() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 670,          // within 50 of 650 minimum
            "riskScore", 0.2,
            "balance", 5000.0
        ));
        assertThat(result.isRequiresReview()).isTrue();
    }

    // ── Risk Score Rules ──────────────────────────────────────────────────────

    @Test
    @DisplayName("Risk score above threshold → soft fail")
    void riskScoreAboveThreshold_softFail() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 720,
            "riskScore", 0.55,           // above 0.4 threshold
            "balance", 5000.0
        ));
        assertThat(result.isEligible()).isFalse();
        assertThat(result.getOutcomes().get(0).getOverridePolicy()).isEqualTo(OverridePolicy.SOFT);
    }

    @Test
    @DisplayName("Risk score near limit → pending review")
    void riskScoreNearLimit_pendingReview() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 720,
            "riskScore", 0.35,           // within 0.1 of 0.4 limit → warning zone
            "balance", 5000.0
        ));
        assertThat(result.isRequiresReview()).isTrue();
    }

    // ── Balance Rules ─────────────────────────────────────────────────────────

    @Test
    @DisplayName("Balance below minimum → hard fail")
    void balanceBelowMin_hardFail() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 720,
            "riskScore", 0.2,
            "balance", 500.0             // below 1000 minimum
        ));
        assertThat(result.isEligible()).isFalse();
        assertThat(result.getOutcomes().get(0).getOverridePolicy()).isEqualTo(OverridePolicy.HARD);
    }

    @Test
    @DisplayName("Zero balance → hard fail")
    void zeroBalance_hardFail() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 720,
            "riskScore", 0.2,
            "balance", 0.0
        ));
        assertThat(result.isEligible()).isFalse();
        assertThat(result.getOutcomes().get(0).getOverridePolicy()).isEqualTo(OverridePolicy.HARD);
    }

    // ── All clear ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("All checks pass → eligible")
    void allCheckPass_eligible() {
        EligibilityResult result = evaluate(Map.of(
            "kycStatus", "VERIFIED",
            "creditScore", 750,
            "riskScore", 0.15,
            "balance", 20000.0
        ));
        assertThat(result.isEligible()).isTrue();
        assertThat(result.isRequiresReview()).isFalse();
        assertThat(result.getOutcomes().get(0).getReason()).isEqualTo("All checks passed");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private EligibilityResult evaluate(Map<String, Object> entityData) {
        WorkflowContext ctx = WorkflowContext.builder()
            .instanceId("test-" + System.currentTimeMillis())
            .workflowType("LOAN_APPLICATION")
            .entityId("ent-001")
            .entityType("CUSTOMER")
            .entityData(entityData)
            .contextData(Map.of())
            .inputData(entityData)
            .build();
        return droolsService.evaluate(loanDefinition, ctx);
    }

    private WorkflowDefinition.CheckConfig checkConfig(String id, Map<String, Object> params) {
        WorkflowDefinition.CheckConfig cfg = new WorkflowDefinition.CheckConfig();
        cfg.setCheckId(id);
        cfg.setParams(params);
        return cfg;
    }
}
