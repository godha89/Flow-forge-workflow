package com.flowforge.engine.registry;

import com.flowforge.model.domain.WorkflowDefinition;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;

@Repository
public interface WorkflowDefinitionRepository extends MongoRepository<WorkflowDefinition, String> {

    Optional<WorkflowDefinition> findByWorkflowTypeAndActiveTrue(String workflowType);

    List<WorkflowDefinition> findAllByActiveTrue();

    boolean existsByWorkflowType(String workflowType);
}
