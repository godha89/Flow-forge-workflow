package com.flowforge.model.enums;

public enum CheckResultStatus {
    PASS, FAIL, SKIPPED, PENDING_REVIEW
}
