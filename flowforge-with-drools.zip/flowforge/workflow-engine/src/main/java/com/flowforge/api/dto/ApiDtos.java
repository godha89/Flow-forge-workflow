package com.flowforge.api.dto;

import com.flowforge.model.enums.WorkflowStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.Map;

// ── Start Workflow Request ────────────────────────────────────────────────────

@Data
class StartWorkflowRequest {
    @NotBlank String workflowType;
    @NotBlank String entityId;
    @NotBlank String entityType;
    Map<String, Object> inputData;
    String requestedBy;
}

// ── Workflow Instance Response ────────────────────────────────────────────────

@Data
class WorkflowInstanceResponse {
    String id;
    String workflowType;
    String workflowVersion;
    WorkflowStatus status;
    String entityId;
    String entityType;
    String currentStep;
    Instant createdAt;
    Instant updatedAt;
    Instant completedAt;
    String errorMessage;
    List<CheckOutcomeDto> eligibilityResults;
    List<AuditEventDto> auditTrail;
}

@Data
class CheckOutcomeDto {
    String checkId;
    String checkName;
    String status;
    String reason;
    Long durationMs;
    Map<String, Object> metadata;
}

@Data
class AuditEventDto {
    String id;
    String eventType;
    String fromStatus;
    String toStatus;
    String stepId;
    String description;
    Long durationMs;
    String actor;
    Instant createdAt;
}

// ── Workflow Definition DTOs ──────────────────────────────────────────────────

@Data
class WorkflowDefinitionDto {
    String id;
    String workflowType;
    String version;
    String description;
    boolean active;
    Object eligibility;
    Object processes;
    Object statusTransitions;
    Instant createdAt;
    Instant updatedAt;
    String createdBy;
}

// ── Check Registry Response ───────────────────────────────────────────────────

@Data
class CheckRegistryEntryDto {
    String checkId;
    String name;
    boolean cacheable;
    String className;
}

// ── Dashboard Stats ───────────────────────────────────────────────────────────

@Data
class DashboardStatsDto {
    long totalToday;
    long activeNow;
    long approvedToday;
    long rejectedToday;
    long pendingReview;
    Map<String, Long> byWorkflowType;
    Map<String, Long> byStatus;
}

// ── Manual Override Request ───────────────────────────────────────────────────

@Data
class OverrideRequest {
    @NotBlank String decision;   // APPROVE | REJECT
    String reason;
    String reviewedBy;
}

// Make these public for controller use
public class ApiDtos {
    public static Class<StartWorkflowRequest> startWorkflowRequest() { return StartWorkflowRequest.class; }

    @Data
    public static class StartRequest {
        @NotBlank public String workflowType;
        @NotBlank public String entityId;
        @NotBlank public String entityType;
        public Map<String, Object> inputData;
        public String requestedBy;
    }

    @Data
    public static class InstanceResponse {
        public String id;
        public String workflowType;
        public String workflowVersion;
        public WorkflowStatus status;
        public String entityId;
        public String entityType;
        public String currentStep;
        public Instant createdAt;
        public Instant updatedAt;
        public Instant completedAt;
        public String errorMessage;
    }

    @Data
    public static class OverrideReq {
        @NotBlank public String decision;
        public String reason;
        public String reviewedBy;
    }

    @Data
    public static class StatsResponse {
        public long totalToday;
        public long activeNow;
        public long approvedToday;
        public long rejectedToday;
        public long pendingReview;
        public Map<String, Long> byWorkflowType;
        public Map<String, Long> byStatus;
    }
}
