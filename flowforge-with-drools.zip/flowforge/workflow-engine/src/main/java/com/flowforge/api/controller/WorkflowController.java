package com.flowforge.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.api.dto.ApiDtos;
import com.flowforge.eligibility.registry.CheckRegistry;
import com.flowforge.engine.core.WorkflowEngine;
import com.flowforge.engine.registry.WorkflowAuditRepository;
import com.flowforge.engine.registry.WorkflowDefinitionRepository;
import com.flowforge.engine.registry.WorkflowInstanceRepository;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.domain.WorkflowInstance;
import com.flowforge.model.enums.WorkflowStatus;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/workflows")
@RequiredArgsConstructor
@Tag(name = "Workflow Engine", description = "Start, track, and manage workflow instances")
@CrossOrigin(origins = "*")
public class WorkflowController {

    private static final Logger log = LogManager.getLogger(WorkflowController.class);

    private final WorkflowEngine engine;
    private final WorkflowInstanceRepository instanceRepository;
    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowAuditRepository auditRepository;
    private final CheckRegistry checkRegistry;
    private final ObjectMapper objectMapper;

    // ── Start Workflow ────────────────────────────────────────────────────────

    @PostMapping("/{type}/start")
    @Operation(summary = "Start a new workflow instance")
    public ResponseEntity<WorkflowInstance> start(
            @PathVariable String type,
            @RequestBody @Valid ApiDtos.StartRequest req) {

        log.info("API: Starting workflow type={} entityId={}", type, req.getEntityId());
        WorkflowInstance instance = engine.startWorkflow(
            type.toUpperCase(),
            req.getEntityId(),
            req.getEntityType(),
            req.getInputData() != null ? req.getInputData() : Map.of(),
            req.getRequestedBy()
        );
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(instance);
    }

    // ── Get Instance ──────────────────────────────────────────────────────────

    @GetMapping("/{id}")
    @Operation(summary = "Get workflow instance by ID")
    public ResponseEntity<WorkflowInstance> getInstance(@PathVariable String id) {
        return instanceRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    // ── Get Audit Trail ───────────────────────────────────────────────────────

    @GetMapping("/{id}/audit")
    @Operation(summary = "Get full audit trail for a workflow instance")
    public ResponseEntity<?> getAuditTrail(@PathVariable String id) {
        if (!instanceRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(
            auditRepository.findByWorkflowInstanceIdOrderByCreatedAtAsc(id));
    }

    // ── List Instances ────────────────────────────────────────────────────────

    @GetMapping
    @Operation(summary = "List workflow instances with optional filters")
    public ResponseEntity<Page<WorkflowInstance>> list(
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String entityId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {

        PageRequest pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));

        if (type != null) {
            return ResponseEntity.ok(instanceRepository.findByWorkflowType(type.toUpperCase(), pageable));
        }
        if (status != null) {
            return ResponseEntity.ok(instanceRepository.findByStatus(WorkflowStatus.valueOf(status), pageable));
        }
        if (entityId != null) {
            return ResponseEntity.ok(instanceRepository.findByEntityId(entityId, pageable));
        }
        return ResponseEntity.ok(instanceRepository.findAll(pageable));
    }

    // ── Manual Override (PENDING_REVIEW) ──────────────────────────────────────

    @PostMapping("/{id}/override")
    @Operation(summary = "Manually approve or reject a PENDING_REVIEW instance")
    public ResponseEntity<?> override(
            @PathVariable String id,
            @RequestBody @Valid ApiDtos.OverrideReq req) {

        return instanceRepository.findById(id).map(instance -> {
            if (instance.getStatus() != WorkflowStatus.PENDING_REVIEW) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Instance is not in PENDING_REVIEW state"));
            }

            WorkflowStatus newStatus = "APPROVE".equalsIgnoreCase(req.getDecision())
                ? WorkflowStatus.ELIGIBLE : WorkflowStatus.REJECTED;

            instance.setStatus(newStatus);
            instance.setUpdatedAt(Instant.now());
            if (newStatus == WorkflowStatus.REJECTED) {
                instance.setCompletedAt(Instant.now());
            }
            instanceRepository.save(instance);

            log.info("Manual override: instance={} decision={} by={}",
                id, req.getDecision(), req.getReviewedBy());

            // If approved, resume execution
            if (newStatus == WorkflowStatus.ELIGIBLE) {
                definitionRepository.findByWorkflowTypeAndActiveTrue(instance.getWorkflowType())
                    .ifPresent(def -> engine.executeAsync(id, def));
            }

            return ResponseEntity.ok(instance);
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── Cancel ────────────────────────────────────────────────────────────────

    @PostMapping("/{id}/cancel")
    @Operation(summary = "Cancel a workflow instance")
    public ResponseEntity<?> cancel(@PathVariable String id,
                                     @RequestBody(required = false) Map<String, String> body) {
        return instanceRepository.findById(id).map(instance -> {
            if (List.of(WorkflowStatus.APPROVED, WorkflowStatus.REJECTED,
                        WorkflowStatus.CANCELLED, WorkflowStatus.FAILED)
                    .contains(instance.getStatus())) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Cannot cancel a terminal workflow"));
            }
            instance.setStatus(WorkflowStatus.CANCELLED);
            instance.setCompletedAt(Instant.now());
            instance.setUpdatedAt(Instant.now());
            instanceRepository.save(instance);
            return ResponseEntity.ok(instance);
        }).orElse(ResponseEntity.notFound().build());
    }

    // ── Dashboard Stats ───────────────────────────────────────────────────────

    @GetMapping("/stats/dashboard")
    @Operation(summary = "Get dashboard statistics")
    public ResponseEntity<ApiDtos.StatsResponse> dashboardStats() {
        Instant startOfDay = Instant.now().truncatedTo(ChronoUnit.DAYS);

        ApiDtos.StatsResponse stats = new ApiDtos.StatsResponse();
        stats.totalToday = instanceRepository.countCreatedSince(startOfDay);

        List<WorkflowStatus> terminalStatuses = List.of(
            WorkflowStatus.APPROVED, WorkflowStatus.REJECTED,
            WorkflowStatus.CANCELLED, WorkflowStatus.FAILED);

        Page<WorkflowInstance> active = instanceRepository.findByStatus(
            WorkflowStatus.PROCESSING, PageRequest.of(0, 1));
        stats.activeNow = active.getTotalElements();

        Page<WorkflowInstance> pendingReview = instanceRepository.findByStatus(
            WorkflowStatus.PENDING_REVIEW, PageRequest.of(0, 1));
        stats.pendingReview = pendingReview.getTotalElements();

        return ResponseEntity.ok(stats);
    }

    // ── Check Registry ────────────────────────────────────────────────────────

    @GetMapping("/checks/registry")
    @Operation(summary = "List all registered eligibility checks")
    public ResponseEntity<?> listChecks() {
        return ResponseEntity.ok(
            checkRegistry.getAllChecks().entrySet().stream()
                .map(e -> Map.of(
                    "checkId",   e.getKey(),
                    "name",      e.getValue().getName(),
                    "cacheable", e.getValue().isCacheable(),
                    "class",     e.getValue().getClass().getSimpleName()
                ))
                .collect(Collectors.toList())
        );
    }

    // ── Workflow Definitions ──────────────────────────────────────────────────

    @GetMapping("/definitions")
    @Operation(summary = "List all active workflow definitions")
    public ResponseEntity<List<WorkflowDefinition>> listDefinitions() {
        return ResponseEntity.ok(definitionRepository.findAllByActiveTrue());
    }

    @GetMapping("/definitions/{type}")
    @Operation(summary = "Get workflow definition by type")
    public ResponseEntity<WorkflowDefinition> getDefinition(@PathVariable String type) {
        return definitionRepository.findByWorkflowTypeAndActiveTrue(type.toUpperCase())
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/definitions")
    @Operation(summary = "Create or update a workflow definition")
    public ResponseEntity<WorkflowDefinition> upsertDefinition(
            @RequestBody WorkflowDefinition definition) {
        definition.setUpdatedAt(Instant.now());
        if (definition.getCreatedAt() == null) {
            definition.setCreatedAt(Instant.now());
        }
        return ResponseEntity.ok(definitionRepository.save(definition));
    }
}
