package com.flowforge.eligibility.drools;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * EligibilityFact — the single object inserted into the Drools session.
 *
 * Think of this as a "form" that gets filled in:
 *   - You fill in the applicant's details (kycStatus, creditScore, etc.)
 *   - Drools rules read those details and write the result fields (approved, reason)
 *
 * Plain Java — no Drools imports needed here.
 * Business teams only need to understand the field names to write rules.
 */
@Data
@NoArgsConstructor
public class EligibilityFact {

    // ── Input fields — filled from workflow context before rules run ──────────

    /** e.g. "VERIFIED", "PENDING", "FAILED" */
    private String kycStatus;

    /** e.g. 720 */
    private int creditScore;

    /** 0.0 (no risk) to 1.0 (maximum risk) */
    private double riskScore;

    /** Account balance in currency units */
    private double balance;

    /** Minimum balance required — set from workflow definition params */
    private double requiredBalance;

    /** Minimum credit score required — set from workflow definition params */
    private int requiredCreditScore;

    /** Maximum risk score allowed — set from workflow definition params */
    private double maxRiskScore;

    /** Customer age */
    private int age;

    /** Workflow type — allows rules to be workflow-specific */
    private String workflowType;

    /** Entity type — e.g. "CUSTOMER", "BUSINESS" */
    private String entityType;

    // ── Output fields — written by Drools rules ───────────────────────────────

    /**
     * Final verdict set by rules:
     * "PASS", "FAIL", or "REVIEW" (soft fail needing human approval)
     */
    private String result = "PASS";  // optimistic default — rules set FAIL/REVIEW

    /** Human-readable explanation, set by the failing/reviewing rule */
    private String reason = "All checks passed";

    /**
     * Override policy set by the rule that triggered failure:
     * "HARD" = never overridable, "SOFT" = needs human approval
     */
    private String overridePolicy = "SOFT";

    /**
     * Which rule name fired and set the result.
     * Helps with debugging — shows exactly which rule was responsible.
     */
    private String firedRule;

    // ── Convenience setters called directly from .drl rule files ─────────────

    public void fail(String ruleName, String failReason, String policy) {
        this.result = "FAIL";
        this.reason = failReason;
        this.firedRule = ruleName;
        this.overridePolicy = policy;
    }

    public void review(String ruleName, String reviewReason) {
        this.result = "REVIEW";
        this.reason = reviewReason;
        this.firedRule = ruleName;
        this.overridePolicy = "SOFT";
    }
}
