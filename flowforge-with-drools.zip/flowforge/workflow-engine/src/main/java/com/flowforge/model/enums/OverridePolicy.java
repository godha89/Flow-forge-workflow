package com.flowforge.model.enums;

public enum OverridePolicy {
    HARD,   // Never overridable — immediate rejection
    SOFT,   // Requires human approval
    AUTO,   // Rule-based automatic override
    SKIP    // Conditionally skippable
}
