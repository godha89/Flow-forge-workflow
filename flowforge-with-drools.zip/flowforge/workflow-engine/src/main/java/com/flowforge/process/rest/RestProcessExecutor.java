package com.flowforge.process.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.domain.WorkflowInstance;
import com.flowforge.observability.WorkflowLogger;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * Executes REST process steps synchronously.
 *
 * Features:
 * - Configurable timeout per step
 * - Exponential-backoff retry from WorkflowDefinition.RetryConfig
 * - Response mapping: maps JSON response fields into workflow context
 * - Request mapping: builds request body from context fields
 */
@Service
@RequiredArgsConstructor
public class RestProcessExecutor {

    private static final Logger log = LogManager.getLogger(RestProcessExecutor.class);

    private final WebClient.Builder webClientBuilder;
    private final ObjectMapper objectMapper;
    private final WorkflowLogger workflowLogger;

    public ProcessResult execute(WorkflowDefinition.ProcessStep step,
                                  WorkflowInstance instance,
                                  Map<String, Object> context) {

        long start = System.currentTimeMillis();
        String instanceId = instance.getId();
        String stepId = step.getId();

        workflowLogger.logProcessStart(instanceId, stepId, "REST");
        workflowLogger.bindStep(stepId);

        log.info("[{}] REST step [{}]: {} {}", instanceId, stepId, step.getMethod(), step.getEndpoint());

        try {
            // Build request body from context mappings
            Map<String, Object> requestBody = buildRequestBody(step, context, instance);

            // Configure WebClient with timeout
            int timeoutMs = step.getTimeoutMs() != null ? step.getTimeoutMs() : 10_000;
            WebClient client = webClientBuilder.build();

            // Execute with retry
            String responseJson = client
                .method(HttpMethod.valueOf(step.getMethod() != null ? step.getMethod() : "POST"))
                .uri(step.getEndpoint())
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(String.class)
                .timeout(Duration.ofMillis(timeoutMs))
                .retryWhen(buildRetrySpec(step.getRetry()))
                .block();

            // Map response fields into context
            Map<String, Object> updatedContext = applyResponseMapping(step, responseJson, context);
            long durationMs = System.currentTimeMillis() - start;

            workflowLogger.logProcessComplete(instanceId, stepId, durationMs, true);
            log.debug("[{}] REST step [{}] response mapped {} fields", instanceId, stepId,
                step.getResponseMapping() != null ? step.getResponseMapping().size() : 0);

            return ProcessResult.builder()
                .stepId(stepId)
                .success(true)
                .updatedContext(updatedContext)
                .durationMs(durationMs)
                .build();

        } catch (WebClientResponseException ex) {
            long durationMs = System.currentTimeMillis() - start;
            log.error("[{}] REST step [{}] HTTP error: {} {}", instanceId, stepId,
                ex.getStatusCode(), ex.getMessage());
            workflowLogger.logProcessComplete(instanceId, stepId, durationMs, false);

            return ProcessResult.builder()
                .stepId(stepId)
                .success(false)
                .errorMessage(String.format("HTTP %s: %s", ex.getStatusCode(), ex.getMessage()))
                .durationMs(durationMs)
                .build();

        } catch (Exception ex) {
            long durationMs = System.currentTimeMillis() - start;
            workflowLogger.logError(instanceId, "REST step " + stepId, ex);

            return ProcessResult.builder()
                .stepId(stepId)
                .success(false)
                .errorMessage(ex.getMessage())
                .durationMs(durationMs)
                .build();

        } finally {
            workflowLogger.unbindStep();
        }
    }

    private Map<String, Object> buildRequestBody(WorkflowDefinition.ProcessStep step,
                                                   Map<String, Object> context,
                                                   WorkflowInstance instance) {
        Map<String, Object> body = new HashMap<>();
        body.put("workflowInstanceId", instance.getId());
        body.put("entityId", instance.getEntityId());
        body.put("entityType", instance.getEntityType());

        if (step.getRequestMapping() != null) {
            step.getRequestMapping().forEach((bodyKey, contextPath) -> {
                Object value = resolveContextPath(context, contextPath);
                if (value != null) {
                    body.put(bodyKey, value);
                }
            });
        }
        return body;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> applyResponseMapping(WorkflowDefinition.ProcessStep step,
                                                      String responseJson,
                                                      Map<String, Object> context) {
        Map<String, Object> updated = new HashMap<>(context);
        if (responseJson == null || step.getResponseMapping() == null) {
            return updated;
        }

        try {
            Map<String, Object> response = objectMapper.readValue(responseJson, Map.class);
            step.getResponseMapping().forEach((responseKey, contextKey) -> {
                Object value = response.get(responseKey);
                if (value != null) {
                    updated.put(contextKey, value);
                    log.debug("Mapped response [{}] → context [{}] = {}", responseKey, contextKey, value);
                }
            });
        } catch (Exception e) {
            log.warn("Could not parse response JSON for mapping: {}", e.getMessage());
        }
        return updated;
    }

    private Object resolveContextPath(Map<String, Object> context, String path) {
        // Simple dot-notation resolver: "entity.balance" → context.entity.balance
        String[] parts = path.split("\\.");
        Object current = context;
        for (String part : parts) {
            if (current instanceof Map<?, ?> map) {
                current = map.get(part);
            } else {
                return null;
            }
        }
        return current;
    }

    private Retry buildRetrySpec(WorkflowDefinition.RetryConfig retryConfig) {
        if (retryConfig == null) {
            return Retry.backoff(3, Duration.ofMillis(500))
                .maxBackoff(Duration.ofSeconds(10));
        }
        return Retry.backoff(retryConfig.getMaxAttempts(), Duration.ofMillis(retryConfig.getInitialIntervalMs()))
            .multiplier(retryConfig.getMultiplier())
            .maxBackoff(Duration.ofMillis(retryConfig.getMaxIntervalMs()))
            .filter(ex -> ex instanceof WebClientResponseException webEx &&
                          webEx.getStatusCode().is5xxServerError());
    }

    @Data
    @lombok.Builder
    public static class ProcessResult {
        private String stepId;
        private boolean success;
        private Map<String, Object> updatedContext;
        private String errorMessage;
        private long durationMs;
    }
}
