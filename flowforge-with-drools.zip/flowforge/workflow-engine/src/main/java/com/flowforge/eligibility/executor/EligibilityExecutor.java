package com.flowforge.eligibility.executor;

import com.flowforge.eligibility.drools.DroolsEligibilityService;
import com.flowforge.eligibility.registry.EligibilityCheck;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.CheckResultStatus;
import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.observability.WorkflowLogger;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * EligibilityExecutor — orchestrates eligibility evaluation.
 *
 * HOW IT WORKS NOW (with Drools):
 *   All eligibility logic lives in .drl rule files under src/main/resources/rules/
 *   This class simply hands the workflow context to Drools and returns the verdict.
 *
 * HOW TO ADD A NEW ELIGIBILITY RULE:
 *   1. Open (or create) a .drl file in src/main/resources/rules/
 *   2. Add your rule block — copy/paste any existing rule as a template
 *   3. Restart the application — rules are picked up automatically
 *   NO Java code changes needed.
 *
 * The old Java-based CheckRegistry is kept for any custom programmatic checks
 * that cannot be expressed in rules (e.g. complex external API calls).
 */
@Service
@RequiredArgsConstructor
public class EligibilityExecutor {

    private static final Logger log = LogManager.getLogger(EligibilityExecutor.class);

    private final DroolsEligibilityService droolsService;   // new Drools path
    private final WorkflowLogger workflowLogger;

    public EligibilityResult execute(
            WorkflowDefinition definition,
            EligibilityCheck.WorkflowContext context) {

        log.info("[{}] Delegating eligibility to Drools rules engine for workflowType={}",
            context.getInstanceId(), context.getWorkflowType());

        // All rules in .drl files are evaluated in one Drools session
        EligibilityResult result = droolsService.evaluate(definition, context);

        log.info("[{}] Eligibility complete: eligible={} requiresReview={}",
            context.getInstanceId(), result.isEligible(), result.isRequiresReview());

        return result;
    }

    // ── Result DTOs ───────────────────────────────────────────────────────────

    @Data
    public static class EligibilityResult {
        private String instanceId;
        private List<CheckOutcome> outcomes;
        private boolean eligible;
        private boolean requiresReview;

        public boolean isHardFailed() {
            return outcomes.stream().anyMatch(o ->
                o.getStatus() == CheckResultStatus.FAIL &&
                o.getOverridePolicy() == OverridePolicy.HARD);
        }
    }

    @Data
    @lombok.Builder
    public static class CheckOutcome {
        private String checkId;
        private String checkName;
        private CheckResultStatus status;
        private String reason;
        private Map<String, Object> metadata;
        private Long durationMs;
        private OverridePolicy overridePolicy;
    }
}
