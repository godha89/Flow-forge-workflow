package com.flowforge.observability;

import com.flowforge.eligibility.registry.EligibilityCheck;
import com.flowforge.model.enums.WorkflowStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Centralised structured logging for all workflow events.
 *
 * Uses Log4j2 ThreadContext (MDC) so every log line emitted during a
 * workflow operation automatically carries workflowId, instanceId, and stepId.
 * This makes log correlation trivial in ELK / Grafana Loki.
 *
 * Usage:
 *   workflowLogger.bind(instanceId, workflowType);
 *   // ... do work ...
 *   workflowLogger.unbind();
 */
@Component
public class WorkflowLogger {

    private static final Logger log  = LogManager.getLogger(WorkflowLogger.class);
    private static final Logger audit = LogManager.getLogger("AUDIT");

    // ── MDC binding ───────────────────────────────────────────────────────────

    public void bind(String instanceId, String workflowType) {
        ThreadContext.put("instanceId",   instanceId);
        ThreadContext.put("workflowId",   workflowType);
        ThreadContext.put("traceId",      instanceId);   // simple trace = instanceId
    }

    public void bindStep(String stepId) {
        ThreadContext.put("stepId", stepId);
    }

    public void unbindStep() {
        ThreadContext.remove("stepId");
    }

    public void unbind() {
        ThreadContext.clearAll();
    }

    // ── Audit events ──────────────────────────────────────────────────────────

    public void logStatusTransition(String instanceId, WorkflowStatus from, WorkflowStatus to) {
        audit.info("STATUS_TRANSITION | {} → {} | instance={}", from, to, instanceId);
        log.info("[{}] Status transition: {} → {}", instanceId, from, to);
    }

    public void logCheckResult(String instanceId, String checkId, EligibilityCheck.CheckResult result) {
        audit.info("CHECK_RESULT | check={} status={} reason='{}' durationMs={} | instance={}",
            checkId, result.getStatus(), result.getReason(), result.getDurationMs(), instanceId);
        log.info("[{}] Check [{}]: {} — {} ({}ms)",
            instanceId, checkId, result.getStatus(), result.getReason(), result.getDurationMs());
    }

    public void logProcessStart(String instanceId, String stepId, String type) {
        audit.info("PROCESS_START | step={} type={} | instance={}", stepId, type, instanceId);
        log.info("[{}] Process step [{}] starting — type={}", instanceId, stepId, type);
    }

    public void logProcessComplete(String instanceId, String stepId, long durationMs, boolean success) {
        audit.info("PROCESS_COMPLETE | step={} success={} durationMs={} | instance={}",
            stepId, success, durationMs, instanceId);
        log.info("[{}] Process step [{}] completed — success={} ({}ms)",
            instanceId, stepId, success, durationMs);
    }

    public void logAsyncPublished(String instanceId, String stepId, String exchange,
                                   String routingKey, String correlationId) {
        audit.info("ASYNC_PUBLISHED | step={} exchange={} routingKey={} correlationId={} | instance={}",
            stepId, exchange, routingKey, correlationId, instanceId);
        log.info("[{}] Async message published: step={} exchange={} correlationId={}",
            instanceId, stepId, exchange, correlationId);
    }

    public void logAsyncReplyReceived(String instanceId, String correlationId, boolean success) {
        audit.info("ASYNC_REPLY | correlationId={} success={} | instance={}", correlationId, success, instanceId);
        log.info("[{}] Async reply received: correlationId={} success={}", instanceId, correlationId, success);
    }

    public void logError(String instanceId, String context, Throwable ex) {
        audit.error("ERROR | context='{}' error='{}' | instance={}", context, ex.getMessage(), instanceId);
        log.error("[{}] Error in {}: {}", instanceId, context, ex.getMessage(), ex);
    }

    public void logWorkflowStart(String instanceId, String workflowType, String entityId) {
        audit.info("WORKFLOW_START | type={} entityId={} | instance={}", workflowType, entityId, instanceId);
        log.info("[{}] Workflow started: type={} entityId={}", instanceId, workflowType, entityId);
    }

    public void logWorkflowComplete(String instanceId, WorkflowStatus finalStatus, long totalMs) {
        audit.info("WORKFLOW_COMPLETE | finalStatus={} totalMs={} | instance={}", finalStatus, totalMs, instanceId);
        log.info("[{}] Workflow complete: status={} totalMs={}", instanceId, finalStatus, totalMs);
    }

    public void logMetrics(String instanceId, Map<String, Object> metrics) {
        log.info("[{}] METRICS {}", instanceId, metrics);
    }
}
