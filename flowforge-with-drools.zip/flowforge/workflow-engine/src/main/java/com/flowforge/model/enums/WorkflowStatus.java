package com.flowforge.model.enums;

public enum WorkflowStatus {
    INITIATED,
    CHECKING_ELIGIBILITY,
    ELIGIBLE,
    PENDING_REVIEW,      // soft-fail override pending human approval
    PROCESSING,
    AWAITING_ASYNC,      // suspended waiting for RabbitMQ reply
    APPROVED,
    REJECTED,
    CANCELLED,
    FAILED               // unexpected system failure
}
