package com.flowforge.engine.registry;

import com.flowforge.model.domain.WorkflowAuditEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkflowAuditRepository extends JpaRepository<WorkflowAuditEvent, String> {

    List<WorkflowAuditEvent> findByWorkflowInstanceIdOrderByCreatedAtAsc(String instanceId);
}
