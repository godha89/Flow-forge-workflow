package com.flowforge.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    private static final Logger log = LogManager.getLogger(RabbitMQConfig.class);

    @Value("${flowforge.rabbitmq.process-exchange}")
    private String processExchange;

    @Value("${flowforge.rabbitmq.dlx-exchange}")
    private String dlxExchange;

    @Value("${flowforge.rabbitmq.reply-queue}")
    private String replyQueue;

    // ── Exchanges ─────────────────────────────────────────────────────────────

    @Bean
    public TopicExchange processExchange() {
        return ExchangeBuilder.topicExchange(processExchange)
            .durable(true)
            .build();
    }

    @Bean
    public DirectExchange deadLetterExchange() {
        return ExchangeBuilder.directExchange(dlxExchange)
            .durable(true)
            .build();
    }

    // ── Queues ────────────────────────────────────────────────────────────────

    @Bean
    public Queue replyQueue() {
        // Reply queue: async responses come back here
        return QueueBuilder.durable(replyQueue)
            .withArgument("x-message-ttl", 300_000)   // 5 minute TTL
            .build();
    }

    @Bean
    public Queue deadLetterQueue() {
        return QueueBuilder.durable("flowforge.dlq")
            .build();
    }

    // ── Bindings ──────────────────────────────────────────────────────────────

    @Bean
    public Binding replyQueueBinding(Queue replyQueue, TopicExchange processExchange) {
        return BindingBuilder.bind(replyQueue)
            .to(processExchange)
            .with("flowforge.reply.#");
    }

    @Bean
    public Binding deadLetterBinding(Queue deadLetterQueue, DirectExchange deadLetterExchange) {
        return BindingBuilder.bind(deadLetterQueue)
            .to(deadLetterExchange)
            .with("flowforge.dlq");
    }

    // ── Message converter ─────────────────────────────────────────────────────

    @Bean
    public Jackson2JsonMessageConverter messageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(messageConverter());
        template.setReplyTimeout(30_000);
        log.info("RabbitTemplate configured with JSON message converter");
        return template;
    }

    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
            ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setMessageConverter(messageConverter());
        factory.setAcknowledgeMode(AcknowledgeMode.MANUAL);
        factory.setConcurrentConsumers(5);
        factory.setMaxConcurrentConsumers(20);
        return factory;
    }
}
