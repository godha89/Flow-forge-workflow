package com.flowforge.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieModule;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;

/**
 * Drools configuration — loads every .drl file found under src/main/resources/rules/
 *
 * HOW IT WORKS:
 *   1. On startup, Spring scans for all files matching "classpath:rules/*.drl"
 *   2. Each file is compiled into a Drools knowledge base
 *   3. Any compilation error is logged clearly so you know which rule file has a problem
 *
 * TO ADD A NEW RULE FILE:
 *   Just drop a new .drl file into src/main/resources/rules/
 *   It will be picked up automatically on next restart — no code changes needed.
 */
@Configuration
public class DroolsConfig {

    private static final Logger log = LogManager.getLogger(DroolsConfig.class);

    private static final String RULES_PATH = "classpath:rules/*.drl";

    @Bean
    public KieContainer kieContainer() throws IOException {
        KieServices ks = KieServices.Factory.get();
        KieFileSystem kfs = ks.newKieFileSystem();

        // Auto-discover all .drl files in the rules folder
        Resource[] ruleFiles = new PathMatchingResourcePatternResolver()
            .getResources(RULES_PATH);

        if (ruleFiles.length == 0) {
            log.warn("No .drl rule files found at '{}' — Drools will run with no rules loaded", RULES_PATH);
        }

        for (Resource file : ruleFiles) {
            String filename = file.getFilename();
            String content = new String(file.getInputStream().readAllBytes());
            kfs.write("src/main/resources/rules/" + filename, content);
            log.info("Loaded Drools rule file: {}", filename);
        }

        // Compile the rules
        KieBuilder kb = ks.newKieBuilder(kfs).buildAll();

        // Check for compilation errors — log them clearly
        if (kb.getResults().hasMessages(Message.Level.ERROR)) {
            kb.getResults().getMessages(Message.Level.ERROR).forEach(msg ->
                log.error("Drools rule compilation error in [{}] line {}: {}",
                    msg.getPath(), msg.getLine(), msg.getText())
            );
            throw new IllegalStateException(
                "Drools rule files failed to compile — check logs above for details");
        }

        // Log warnings too (won't stop startup but worth knowing about)
        if (kb.getResults().hasMessages(Message.Level.WARNING)) {
            kb.getResults().getMessages(Message.Level.WARNING).forEach(msg ->
                log.warn("Drools rule warning in [{}] line {}: {}",
                    msg.getPath(), msg.getLine(), msg.getText())
            );
        }

        KieModule km = kb.getKieModule();
        KieContainer container = ks.newKieContainer(km.getReleaseId());

        log.info("Drools KieContainer ready — {} rule file(s) compiled successfully", ruleFiles.length);
        return container;
    }
}
