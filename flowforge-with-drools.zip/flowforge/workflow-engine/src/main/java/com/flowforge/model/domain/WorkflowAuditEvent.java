package com.flowforge.model.domain;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.UUID;

/**
 * Immutable audit event — one row per state transition or notable event.
 * Stored in Oracle alongside WorkflowInstance for transactional consistency.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "WORKFLOW_AUDIT_EVENTS",
       indexes = {
           @Index(name = "idx_audit_inst_id", columnList = "INSTANCE_ID"),
           @Index(name = "idx_audit_created", columnList = "CREATED_AT")
       })
public class WorkflowAuditEvent {

    @Id
    @Column(name = "ID", length = 36)
    @Builder.Default
    private String id = UUID.randomUUID().toString();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "INSTANCE_ID", nullable = false)
    private WorkflowInstance workflowInstance;

    @Column(name = "EVENT_TYPE", nullable = false, length = 50)
    private String eventType;      // STATUS_TRANSITION | CHECK_RESULT | PROCESS_CALL | ERROR

    @Column(name = "DESCRIPTION", length = 1000)
    private String description;

    @Column(name = "FROM_STATUS", length = 30)
    private String fromStatus;

    @Column(name = "TO_STATUS", length = 30)
    private String toStatus;

    @Column(name = "STEP_ID", length = 100)
    private String stepId;

    @Column(name = "DURATION_MS")
    private Long durationMs;

    @JdbcTypeCode(SqlTypes.CLOB)
    @Column(name = "DETAILS_JSON")
    private String detailsJson;

    @Column(name = "CREATED_AT", nullable = false)
    private Instant createdAt;

    @Column(name = "ACTOR", length = 100)
    private String actor;          // system | userId for manual overrides
}
