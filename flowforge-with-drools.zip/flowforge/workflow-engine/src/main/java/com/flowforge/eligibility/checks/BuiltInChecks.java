package com.flowforge.eligibility.checks;

import com.flowforge.eligibility.registry.EligibilityCheck;
import com.flowforge.model.enums.CheckResultStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.Map;

// ─────────────────────────────────────────────────────────────────────────────
// 1. KYC_VERIFIED — validates KYC status from entity data or external call
// ─────────────────────────────────────────────────────────────────────────────
@Component
class KycVerifiedCheck implements EligibilityCheck {

    private static final Logger log = LogManager.getLogger(KycVerifiedCheck.class);

    @Override
    public String getCheckId() { return "KYC_VERIFIED"; }

    @Override
    public String getName() { return "KYC Verification"; }

    @Override
    public boolean isCacheable() { return true; }

    @Override
    public CheckResult execute(WorkflowContext context, Map<String, Object> params) {
        long start = System.currentTimeMillis();
        log.debug("[{}] Running KYC_VERIFIED for entity={}", context.getInstanceId(), context.getEntityId());

        Object kycStatus = context.getEntityData().get("kycStatus");

        if (kycStatus == null) {
            return CheckResult.builder()
                .status(CheckResultStatus.FAIL)
                .reason("KYC status not found for entity")
                .durationMs(elapsed(start))
                .build();
        }

        boolean verified = "VERIFIED".equalsIgnoreCase(kycStatus.toString());
        return CheckResult.builder()
            .status(verified ? CheckResultStatus.PASS : CheckResultStatus.FAIL)
            .reason(verified ? "KYC status is VERIFIED" : "KYC status is: " + kycStatus)
            .durationMs(elapsed(start))
            .build();
    }

    private long elapsed(long start) { return System.currentTimeMillis() - start; }
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. BALANCE_SUFFICIENT — checks account balance meets minimum threshold
// ─────────────────────────────────────────────────────────────────────────────
@Component
class BalanceSufficientCheck implements EligibilityCheck {

    private static final Logger log = LogManager.getLogger(BalanceSufficientCheck.class);

    @Override
    public String getCheckId() { return "BALANCE_SUFFICIENT"; }

    @Override
    public String getName() { return "Balance Sufficient"; }

    @Override
    public boolean isCacheable() { return false; }  // balance changes — don't cache

    @Override
    public CheckResult execute(WorkflowContext context, Map<String, Object> params) {
        long start = System.currentTimeMillis();

        double minBalance = params.containsKey("min_balance")
            ? Double.parseDouble(params.get("min_balance").toString())
            : 0.0;

        Object balanceObj = context.getEntityData().get("balance");
        if (balanceObj == null) {
            return CheckResult.builder()
                .status(CheckResultStatus.FAIL)
                .reason("Balance data not available")
                .durationMs(elapsed(start))
                .build();
        }

        double balance = Double.parseDouble(balanceObj.toString());
        boolean sufficient = balance >= minBalance;

        log.debug("[{}] BALANCE_SUFFICIENT: balance={} minBalance={} pass={}", 
            context.getInstanceId(), balance, minBalance, sufficient);

        return CheckResult.builder()
            .status(sufficient ? CheckResultStatus.PASS : CheckResultStatus.FAIL)
            .reason(sufficient
                ? String.format("Balance %.2f meets minimum %.2f", balance, minBalance)
                : String.format("Balance %.2f is below minimum %.2f", balance, minBalance))
            .metadata(Map.of("balance", balance, "minBalance", minBalance))
            .durationMs(elapsed(start))
            .build();
    }

    private long elapsed(long start) { return System.currentTimeMillis() - start; }
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. CREDIT_SCORE_THRESHOLD — validates credit score within configured band
// ─────────────────────────────────────────────────────────────────────────────
@Component
class CreditScoreThresholdCheck implements EligibilityCheck {

    private static final Logger log = LogManager.getLogger(CreditScoreThresholdCheck.class);

    @Override
    public String getCheckId() { return "CREDIT_SCORE_THRESHOLD"; }

    @Override
    public String getName() { return "Credit Score Threshold"; }

    @Override
    public boolean isCacheable() { return true; }

    @Override
    public CheckResult execute(WorkflowContext context, Map<String, Object> params) {
        long start = System.currentTimeMillis();

        int minScore = params.containsKey("min_score") ? Integer.parseInt(params.get("min_score").toString()) : 300;
        int maxScore = params.containsKey("max_score") ? Integer.parseInt(params.get("max_score").toString()) : 900;

        Object scoreObj = context.getEntityData().get("creditScore");
        if (scoreObj == null) {
            // Check context for score from a previous process step
            scoreObj = context.getContextData().get("credit_score");
        }

        if (scoreObj == null) {
            return CheckResult.builder()
                .status(CheckResultStatus.FAIL)
                .reason("Credit score not available")
                .durationMs(elapsed(start))
                .build();
        }

        int score = Integer.parseInt(scoreObj.toString());
        boolean inRange = score >= minScore && score <= maxScore;

        log.debug("[{}] CREDIT_SCORE_THRESHOLD: score={} range=[{},{}] pass={}",
            context.getInstanceId(), score, minScore, maxScore, inRange);

        return CheckResult.builder()
            .status(inRange ? CheckResultStatus.PASS : CheckResultStatus.FAIL)
            .reason(inRange
                ? String.format("Credit score %d within range [%d, %d]", score, minScore, maxScore)
                : String.format("Credit score %d outside range [%d, %d]", score, minScore, maxScore))
            .metadata(Map.of("creditScore", score, "minScore", minScore, "maxScore", maxScore))
            .durationMs(elapsed(start))
            .build();
    }

    private long elapsed(long start) { return System.currentTimeMillis() - start; }
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. RISK_SCORE_LOW — checks risk score is below threshold
// ─────────────────────────────────────────────────────────────────────────────
@Component
class RiskScoreLowCheck implements EligibilityCheck {

    private static final Logger log = LogManager.getLogger(RiskScoreLowCheck.class);

    @Override
    public String getCheckId() { return "RISK_SCORE_LOW"; }

    @Override
    public String getName() { return "Risk Score Low"; }

    @Override
    public boolean isCacheable() { return false; }

    @Override
    public CheckResult execute(WorkflowContext context, Map<String, Object> params) {
        long start = System.currentTimeMillis();

        double threshold = params.containsKey("threshold")
            ? Double.parseDouble(params.get("threshold").toString())
            : 0.5;

        Object riskObj = context.getEntityData().getOrDefault("riskScore",
            context.getContextData().get("risk_score"));

        if (riskObj == null) {
            return CheckResult.builder()
                .status(CheckResultStatus.PENDING_REVIEW)
                .reason("Risk score not yet available — pending review")
                .durationMs(elapsed(start))
                .build();
        }

        double riskScore = Double.parseDouble(riskObj.toString());
        boolean low = riskScore < threshold;

        return CheckResult.builder()
            .status(low ? CheckResultStatus.PASS : CheckResultStatus.FAIL)
            .reason(low
                ? String.format("Risk score %.3f is below threshold %.3f", riskScore, threshold)
                : String.format("Risk score %.3f exceeds threshold %.3f", riskScore, threshold))
            .metadata(Map.of("riskScore", riskScore, "threshold", threshold))
            .durationMs(elapsed(start))
            .build();
    }

    private long elapsed(long start) { return System.currentTimeMillis() - start; }
}
