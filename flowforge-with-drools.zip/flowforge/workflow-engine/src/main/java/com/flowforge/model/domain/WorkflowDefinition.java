package com.flowforge.model.domain;

import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.model.enums.ProcessType;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Workflow definition stored in MongoDB.
 * MongoDB chosen here because workflow definitions are schema-flexible —
 * each workflow type has a different shape for checks and process steps.
 * New workflow types can be added without schema migrations.
 */
@Data
@Document(collection = "workflow_definitions")
public class WorkflowDefinition {

    @Id
    private String id;

    @Indexed(unique = true)
    private String workflowType;   // e.g. "LOAN_APPLICATION"

    private String version;
    private String description;
    private boolean active = true;

    private EligibilityConfig eligibility;
    private List<ProcessStep> processes;
    private StatusTransitionConfig statusTransitions;

    private Instant createdAt;
    private Instant updatedAt;
    private String createdBy;

    @Data
    public static class EligibilityConfig {
        private String mode;          // sequential | parallel | waterfall
        private List<CheckConfig> checks;
    }

    @Data
    public static class CheckConfig {
        private String checkId;       // maps to CheckRegistry key
        private OverridePolicy overridePolicy;
        private boolean required = true;
        private Map<String, Object> params;   // runtime parameters for check
        private String skipCondition;         // SpEL expression for conditional skip
    }

    @Data
    public static class ProcessStep {
        private String id;
        private ProcessType type;          // REST | RABBITMQ
        private String description;
        private List<String> dependsOn;    // step IDs this step waits for

        // REST-specific
        private String endpoint;
        private String method;             // GET | POST | PUT
        private Integer timeoutMs;
        private RetryConfig retry;
        private Map<String, String> requestMapping;   // ctx field → request body key
        private Map<String, String> responseMapping;  // response key → ctx field

        // RabbitMQ-specific
        private String exchange;
        private String routingKey;
        private String replyQueue;
        private String correlationKeyField;     // field from ctx used as correlation id
        private Integer asyncTimeoutMs;
        private String onTimeout;              // SUSPEND | FAIL | SKIP
        private Map<String, String> payloadMapping;
    }

    @Data
    public static class RetryConfig {
        private int maxAttempts = 3;
        private long initialIntervalMs = 500;
        private double multiplier = 2.0;
        private long maxIntervalMs = 10000;
    }

    @Data
    public static class StatusTransitionConfig {
        private String initial;
        private List<String> terminal;
        private Map<String, List<String>> transitions;  // from → [allowed tos]
    }
}
