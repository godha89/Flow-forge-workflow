package com.flowforge.model.enums;

public enum ProcessType {
    REST,
    RABBITMQ
}
