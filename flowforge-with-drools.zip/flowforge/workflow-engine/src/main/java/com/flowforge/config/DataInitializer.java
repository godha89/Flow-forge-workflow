package com.flowforge.config;

import com.flowforge.engine.registry.WorkflowDefinitionRepository;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.model.enums.ProcessType;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Seeds sample workflow definitions into MongoDB on first startup.
 * These are the example definitions shown in the architecture design.
 */
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LogManager.getLogger(DataInitializer.class);

    private final WorkflowDefinitionRepository definitionRepository;

    @Override
    public void run(String... args) {
        seedLoanApplication();
        seedWireTransfer();
        seedAccountOpening();
        log.info("DataInitializer: sample workflow definitions seeded");
    }

    private void seedLoanApplication() {
        if (definitionRepository.existsByWorkflowType("LOAN_APPLICATION")) return;

        WorkflowDefinition def = new WorkflowDefinition();
        def.setWorkflowType("LOAN_APPLICATION");
        def.setVersion("1.0.0");
        def.setDescription("Consumer loan application workflow");
        def.setActive(true);
        def.setCreatedAt(Instant.now());
        def.setUpdatedAt(Instant.now());
        def.setCreatedBy("system");

        // Eligibility
        WorkflowDefinition.EligibilityConfig eligibility = new WorkflowDefinition.EligibilityConfig();
        eligibility.setMode("sequential");

        WorkflowDefinition.CheckConfig kyc = new WorkflowDefinition.CheckConfig();
        kyc.setCheckId("KYC_VERIFIED");
        kyc.setOverridePolicy(OverridePolicy.HARD);
        kyc.setRequired(true);
        kyc.setParams(Map.of());

        WorkflowDefinition.CheckConfig credit = new WorkflowDefinition.CheckConfig();
        credit.setCheckId("CREDIT_SCORE_THRESHOLD");
        credit.setOverridePolicy(OverridePolicy.SOFT);
        credit.setRequired(true);
        credit.setParams(Map.of("min_score", 650, "max_score", 850));

        WorkflowDefinition.CheckConfig risk = new WorkflowDefinition.CheckConfig();
        risk.setCheckId("RISK_SCORE_LOW");
        risk.setOverridePolicy(OverridePolicy.SOFT);
        risk.setRequired(true);
        risk.setParams(Map.of("threshold", 0.4));

        eligibility.setChecks(List.of(kyc, credit, risk));
        def.setEligibility(eligibility);

        // Processes
        WorkflowDefinition.ProcessStep creditPull = new WorkflowDefinition.ProcessStep();
        creditPull.setId("credit_bureau_pull");
        creditPull.setType(ProcessType.REST);
        creditPull.setDescription("Pull credit bureau data");
        creditPull.setEndpoint("http://mock-services:8081/credit/pull");
        creditPull.setMethod("POST");
        creditPull.setTimeoutMs(5000);
        creditPull.setResponseMapping(Map.of("creditScore", "credit_score", "bureau", "bureau_name"));

        WorkflowDefinition.RetryConfig retry = new WorkflowDefinition.RetryConfig();
        retry.setMaxAttempts(3);
        retry.setInitialIntervalMs(500);
        creditPull.setRetry(retry);

        WorkflowDefinition.ProcessStep riskAssess = new WorkflowDefinition.ProcessStep();
        riskAssess.setId("risk_assessment");
        riskAssess.setType(ProcessType.RABBITMQ);
        riskAssess.setDescription("Async risk assessment via RabbitMQ");
        riskAssess.setExchange("flowforge.process.exchange");
        riskAssess.setRoutingKey("risk.assessment.request");
        riskAssess.setReplyQueue("flowforge.reply.queue");
        riskAssess.setAsyncTimeoutMs(30000);
        riskAssess.setOnTimeout("SUSPEND");
        riskAssess.setPayloadMapping(Map.of(
            "entityId", "entityId",
            "creditScore", "credit_score"
        ));
        riskAssess.setDependsOn(List.of("credit_bureau_pull"));

        def.setProcesses(List.of(creditPull, riskAssess));

        // State transitions
        WorkflowDefinition.StatusTransitionConfig transitions = new WorkflowDefinition.StatusTransitionConfig();
        transitions.setInitial("INITIATED");
        transitions.setTerminal(List.of("APPROVED", "REJECTED", "CANCELLED"));
        def.setStatusTransitions(transitions);

        definitionRepository.save(def);
        log.info("Seeded workflow definition: LOAN_APPLICATION");
    }

    private void seedWireTransfer() {
        if (definitionRepository.existsByWorkflowType("WIRE_TRANSFER")) return;

        WorkflowDefinition def = new WorkflowDefinition();
        def.setWorkflowType("WIRE_TRANSFER");
        def.setVersion("1.0.0");
        def.setDescription("Wire transfer authorization workflow");
        def.setActive(true);
        def.setCreatedAt(Instant.now());
        def.setUpdatedAt(Instant.now());
        def.setCreatedBy("system");

        WorkflowDefinition.EligibilityConfig eligibility = new WorkflowDefinition.EligibilityConfig();
        eligibility.setMode("sequential");

        WorkflowDefinition.CheckConfig balance = new WorkflowDefinition.CheckConfig();
        balance.setCheckId("BALANCE_SUFFICIENT");
        balance.setOverridePolicy(OverridePolicy.HARD);
        balance.setRequired(true);
        balance.setParams(Map.of("min_balance", 0));

        WorkflowDefinition.CheckConfig risk = new WorkflowDefinition.CheckConfig();
        risk.setCheckId("RISK_SCORE_LOW");
        risk.setOverridePolicy(OverridePolicy.SOFT);
        risk.setRequired(true);
        risk.setParams(Map.of("threshold", 0.3));

        eligibility.setChecks(List.of(balance, risk));
        def.setEligibility(eligibility);

        WorkflowDefinition.ProcessStep transfer = new WorkflowDefinition.ProcessStep();
        transfer.setId("execute_transfer");
        transfer.setType(ProcessType.REST);
        transfer.setDescription("Execute the wire transfer");
        transfer.setEndpoint("http://mock-services:8081/transfers/execute");
        transfer.setMethod("POST");
        transfer.setTimeoutMs(8000);

        def.setProcesses(List.of(transfer));

        WorkflowDefinition.StatusTransitionConfig transitions = new WorkflowDefinition.StatusTransitionConfig();
        transitions.setInitial("INITIATED");
        transitions.setTerminal(List.of("APPROVED", "REJECTED", "CANCELLED"));
        def.setStatusTransitions(transitions);

        definitionRepository.save(def);
        log.info("Seeded workflow definition: WIRE_TRANSFER");
    }

    private void seedAccountOpening() {
        if (definitionRepository.existsByWorkflowType("ACCOUNT_OPENING")) return;

        WorkflowDefinition def = new WorkflowDefinition();
        def.setWorkflowType("ACCOUNT_OPENING");
        def.setVersion("1.0.0");
        def.setDescription("New account opening workflow");
        def.setActive(true);
        def.setCreatedAt(Instant.now());
        def.setUpdatedAt(Instant.now());
        def.setCreatedBy("system");

        WorkflowDefinition.EligibilityConfig eligibility = new WorkflowDefinition.EligibilityConfig();
        eligibility.setMode("sequential");

        WorkflowDefinition.CheckConfig kyc = new WorkflowDefinition.CheckConfig();
        kyc.setCheckId("KYC_VERIFIED");
        kyc.setOverridePolicy(OverridePolicy.HARD);
        kyc.setRequired(true);
        kyc.setParams(Map.of());

        eligibility.setChecks(List.of(kyc));
        def.setEligibility(eligibility);

        WorkflowDefinition.ProcessStep createAccount = new WorkflowDefinition.ProcessStep();
        createAccount.setId("create_account");
        createAccount.setType(ProcessType.REST);
        createAccount.setDescription("Create account in core banking");
        createAccount.setEndpoint("http://mock-services:8081/accounts/create");
        createAccount.setMethod("POST");
        createAccount.setTimeoutMs(5000);

        def.setProcesses(List.of(createAccount));

        WorkflowDefinition.StatusTransitionConfig transitions = new WorkflowDefinition.StatusTransitionConfig();
        transitions.setInitial("INITIATED");
        transitions.setTerminal(List.of("APPROVED", "REJECTED", "CANCELLED"));
        def.setStatusTransitions(transitions);

        definitionRepository.save(def);
        log.info("Seeded workflow definition: ACCOUNT_OPENING");
    }
}
