package com.flowforge.process.rabbitmq;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.engine.registry.WorkflowInstanceRepository;
import com.flowforge.engine.core.WorkflowEngine;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.domain.WorkflowInstance;
import com.flowforge.model.enums.WorkflowStatus;
import com.flowforge.observability.WorkflowLogger;
import com.rabbitmq.client.Channel;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Handles async process steps via RabbitMQ.
 *
 * PUBLISH flow:
 *   1. Build message payload from context + step mappings
 *   2. Set correlationId = instanceId + stepId
 *   3. Publish to step-configured exchange / routing key
 *   4. Update instance status to AWAITING_ASYNC + persist correlationId
 *   5. Return — workflow is suspended
 *
 * RESUME flow (via @RabbitListener on reply queue):
 *   1. Match correlationId → WorkflowInstance
 *   2. Apply payload mapping into context
 *   3. Resume engine from the next step
 */
@Service
@RequiredArgsConstructor
public class RabbitMQProcessExecutor {

    private static final Logger log = LogManager.getLogger(RabbitMQProcessExecutor.class);

    private final RabbitTemplate rabbitTemplate;
    private final ObjectMapper objectMapper;
    private final WorkflowLogger workflowLogger;
    private final WorkflowInstanceRepository instanceRepository;

    // ── Publish ───────────────────────────────────────────────────────────────

    public PublishResult publish(WorkflowDefinition.ProcessStep step,
                                  WorkflowInstance instance,
                                  Map<String, Object> context) {

        String instanceId = instance.getId();
        String stepId = step.getId();
        String correlationId = instanceId + ":" + stepId + ":" + UUID.randomUUID();

        workflowLogger.logProcessStart(instanceId, stepId, "RABBITMQ");
        workflowLogger.bindStep(stepId);

        try {
            Map<String, Object> payload = buildPayload(step, context, instance);
            String payloadJson = objectMapper.writeValueAsString(payload);

            MessageProperties props = new MessageProperties();
            props.setCorrelationId(correlationId);
            props.setReplyTo(step.getReplyQueue());
            props.setContentType(MessageProperties.CONTENT_TYPE_JSON);
            props.setExpiration(String.valueOf(
                step.getAsyncTimeoutMs() != null ? step.getAsyncTimeoutMs() : 120_000));

            Message message = new Message(payloadJson.getBytes(), props);

            rabbitTemplate.send(step.getExchange(), step.getRoutingKey(), message);

            workflowLogger.logAsyncPublished(instanceId, stepId, step.getExchange(),
                step.getRoutingKey(), correlationId);

            log.info("[{}] Published async message: step={} exchange={} routingKey={} correlationId={}",
                instanceId, stepId, step.getExchange(), step.getRoutingKey(), correlationId);

            return PublishResult.builder()
                .correlationId(correlationId)
                .stepId(stepId)
                .published(true)
                .build();

        } catch (Exception ex) {
            workflowLogger.logError(instanceId, "RabbitMQ publish step " + stepId, ex);
            return PublishResult.builder()
                .stepId(stepId)
                .published(false)
                .errorMessage(ex.getMessage())
                .build();
        } finally {
            workflowLogger.unbindStep();
        }
    }

    // ── Reply Consumer ────────────────────────────────────────────────────────

    @RabbitListener(queues = "${flowforge.rabbitmq.reply-queue}",
                    containerFactory = "rabbitListenerContainerFactory")
    @Transactional
    public void onReplyReceived(Message message, Channel channel,
                                @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag) {
        String correlationId = message.getMessageProperties().getCorrelationId();
        log.info("Async reply received: correlationId={}", correlationId);

        try {
            WorkflowInstance instance = instanceRepository
                .findByAsyncCorrelationId(correlationId)
                .orElse(null);

            if (instance == null) {
                log.warn("No workflow instance found for correlationId={} — discarding reply", correlationId);
                channel.basicAck(deliveryTag, false);
                return;
            }

            workflowLogger.bind(instance.getId(), instance.getWorkflowType());

            String bodyJson = new String(message.getBody());
            boolean success = isSuccessReply(bodyJson);

            workflowLogger.logAsyncReplyReceived(instance.getId(), correlationId, success);

            // Apply payload mapping into context, then signal engine to resume
            Map<String, Object> replyData = objectMapper.readValue(bodyJson, Map.class);

            // Store reply data in instance context for engine to pick up
            Map<String, Object> existingContext = objectMapper.readValue(
                instance.getContextJson() != null ? instance.getContextJson() : "{}",
                Map.class);
            existingContext.put("_asyncReply_" + correlationId, replyData);
            existingContext.put("_asyncSuccess_" + correlationId, success);
            instance.setContextJson(objectMapper.writeValueAsString(existingContext));
            instance.setStatus(WorkflowStatus.PROCESSING);  // resume processing
            instance.setUpdatedAt(Instant.now());
            instanceRepository.save(instance);

            // Signal via application event — WorkflowEngine picks this up
            log.info("[{}] Async reply processed — instance resumed for correlationId={}",
                instance.getId(), correlationId);

            channel.basicAck(deliveryTag, false);
            workflowLogger.unbind();

        } catch (Exception ex) {
            log.error("Error processing async reply correlationId={}: {}", correlationId, ex.getMessage(), ex);
            try {
                channel.basicNack(deliveryTag, false, true);  // requeue
            } catch (Exception ackEx) {
                log.error("Failed to nack message: {}", ackEx.getMessage());
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Map<String, Object> buildPayload(WorkflowDefinition.ProcessStep step,
                                              Map<String, Object> context,
                                              WorkflowInstance instance) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("workflowInstanceId", instance.getId());
        payload.put("workflowType",       instance.getWorkflowType());
        payload.put("entityId",           instance.getEntityId());
        payload.put("entityType",         instance.getEntityType());

        if (step.getPayloadMapping() != null) {
            step.getPayloadMapping().forEach((payloadKey, contextKey) -> {
                Object value = context.get(contextKey);
                if (value != null) {
                    payload.put(payloadKey, value);
                }
            });
        }
        return payload;
    }

    @SuppressWarnings("unchecked")
    private boolean isSuccessReply(String bodyJson) {
        try {
            Map<String, Object> body = objectMapper.readValue(bodyJson, Map.class);
            Object status = body.get("status");
            if (status != null) {
                return "SUCCESS".equalsIgnoreCase(status.toString()) ||
                       "OK".equalsIgnoreCase(status.toString());
            }
            // Assume success if no explicit status field
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Data
    @lombok.Builder
    public static class PublishResult {
        private String stepId;
        private String correlationId;
        private boolean published;
        private String errorMessage;
    }
}
