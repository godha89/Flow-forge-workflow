package com.flowforge.eligibility.registry;

import com.flowforge.model.enums.CheckResultStatus;
import lombok.Builder;
import lombok.Data;

import java.util.Map;

/**
 * Core plug-in interface for eligibility checks.
 *
 * To register a new check:
 *   1. Implement this interface
 *   2. Annotate the class with @Component (or @Service)
 *   3. Spring will auto-discover and register it via CheckRegistry
 *
 * That's it — no other changes needed.
 */
public interface EligibilityCheck {

    /**
     * Unique identifier used in workflow definitions to reference this check.
     * e.g. "KYC_VERIFIED", "CREDIT_SCORE_THRESHOLD"
     */
    String getCheckId();

    /**
     * Human-readable name shown in audit logs and UI.
     */
    String getName();

    /**
     * Whether results can be cached within a workflow session.
     * If true, the same check won't be called twice for the same entity.
     */
    boolean isCacheable();

    /**
     * Execute the eligibility check.
     *
     * @param context  Workflow context carrying entity data and accumulated results
     * @param params   Per-workflow-definition parameters (e.g. min_score: 650)
     * @return         CheckResult with status, reason, and optional metadata
     */
    CheckResult execute(WorkflowContext context, Map<String, Object> params);

    @Data
    @Builder
    class CheckResult {
        private CheckResultStatus status;
        private String reason;
        private Map<String, Object> metadata;   // extra data attached to audit trail
        private long durationMs;
    }

    @Data
    @Builder
    class WorkflowContext {
        private String instanceId;
        private String workflowType;
        private String entityId;
        private String entityType;
        private Map<String, Object> entityData;   // deserialized entity attributes
        private Map<String, Object> contextData;  // accumulated results so far
        private Map<String, Object> inputData;    // original request input
    }
}
