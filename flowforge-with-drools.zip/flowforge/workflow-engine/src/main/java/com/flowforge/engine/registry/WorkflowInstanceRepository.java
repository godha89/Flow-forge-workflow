package com.flowforge.engine.registry;

import com.flowforge.model.domain.WorkflowInstance;
import com.flowforge.model.enums.WorkflowStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface WorkflowInstanceRepository extends JpaRepository<WorkflowInstance, String> {

    Page<WorkflowInstance> findByWorkflowType(String workflowType, Pageable pageable);

    Page<WorkflowInstance> findByStatus(WorkflowStatus status, Pageable pageable);

    Page<WorkflowInstance> findByEntityId(String entityId, Pageable pageable);

    List<WorkflowInstance> findByStatusAndCreatedAtBefore(WorkflowStatus status, Instant before);

    Optional<WorkflowInstance> findByAsyncCorrelationId(String correlationId);

    @Query("SELECT w FROM WorkflowInstance w WHERE w.workflowType = :type AND w.status NOT IN :terminalStatuses")
    List<WorkflowInstance> findActiveByType(@Param("type") String type,
                                             @Param("terminalStatuses") List<WorkflowStatus> terminalStatuses);

    @Query("SELECT w.status, COUNT(w) FROM WorkflowInstance w WHERE w.workflowType = :type GROUP BY w.status")
    List<Object[]> countByStatusForType(@Param("type") String type);

    @Query("SELECT COUNT(w) FROM WorkflowInstance w WHERE w.createdAt >= :since")
    long countCreatedSince(@Param("since") Instant since);
}
