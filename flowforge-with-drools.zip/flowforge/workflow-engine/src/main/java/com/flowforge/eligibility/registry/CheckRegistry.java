package com.flowforge.eligibility.registry;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Central registry for all EligibilityCheck implementations.
 *
 * Spring automatically injects all beans implementing EligibilityCheck.
 * The registry maps each check by its ID for fast O(1) lookup at runtime.
 *
 * To add a new check, just implement EligibilityCheck and annotate with @Component.
 */
@Component
@RequiredArgsConstructor
public class CheckRegistry {

    private static final Logger log = LogManager.getLogger(CheckRegistry.class);

    // All EligibilityCheck beans auto-wired by Spring
    private final List<EligibilityCheck> checks;

    private final Map<String, EligibilityCheck> registry = new ConcurrentHashMap<>();

    @PostConstruct
    public void init() {
        for (EligibilityCheck check : checks) {
            String id = check.getCheckId();
            if (registry.containsKey(id)) {
                throw new IllegalStateException(
                    "Duplicate EligibilityCheck registration for id: " + id);
            }
            registry.put(id, check);
            log.info("Registered eligibility check: [{}] -> {}", id, check.getClass().getSimpleName());
        }
        log.info("CheckRegistry initialized with {} checks: {}", registry.size(), registry.keySet());
    }

    public Optional<EligibilityCheck> findById(String checkId) {
        return Optional.ofNullable(registry.get(checkId));
    }

    public EligibilityCheck getById(String checkId) {
        return findById(checkId).orElseThrow(() ->
            new IllegalArgumentException("No eligibility check registered with id: " + checkId));
    }

    public Map<String, EligibilityCheck> getAllChecks() {
        return Map.copyOf(registry);
    }

    public boolean isRegistered(String checkId) {
        return registry.containsKey(checkId);
    }
}
