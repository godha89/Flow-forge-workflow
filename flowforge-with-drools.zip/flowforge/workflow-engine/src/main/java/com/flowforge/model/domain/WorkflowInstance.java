package com.flowforge.model.domain;

import com.flowforge.model.enums.WorkflowStatus;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
 * Workflow instance state stored in Oracle.
 * Oracle chosen here because instance state and audit trail need ACID guarantees —
 * status transitions must be atomic and consistent across retries.
 */
@Data
@NoArgsConstructor
@Entity
@Table(name = "WORKFLOW_INSTANCES",
       indexes = {
           @Index(name = "idx_wf_inst_type", columnList = "WORKFLOW_TYPE"),
           @Index(name = "idx_wf_inst_status", columnList = "STATUS"),
           @Index(name = "idx_wf_inst_entity", columnList = "ENTITY_ID")
       })
public class WorkflowInstance {

    @Id
    @Column(name = "ID", length = 36)
    private String id = UUID.randomUUID().toString();

    @Column(name = "WORKFLOW_TYPE", nullable = false, length = 100)
    private String workflowType;

    @Column(name = "WORKFLOW_VERSION", length = 20)
    private String workflowVersion;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 30)
    private WorkflowStatus status;

    @Column(name = "ENTITY_ID", length = 100)
    private String entityId;        // e.g. customer ID, account ID

    @Column(name = "ENTITY_TYPE", length = 50)
    private String entityType;      // e.g. "CUSTOMER", "ACCOUNT"

    @Column(name = "CURRENT_STEP", length = 100)
    private String currentStep;

    // Serialized workflow context (input + accumulated results)
    @JdbcTypeCode(SqlTypes.CLOB)
    @Column(name = "CONTEXT_JSON")
    private String contextJson;

    // Serialized eligibility results
    @JdbcTypeCode(SqlTypes.CLOB)
    @Column(name = "ELIGIBILITY_RESULTS_JSON")
    private String eligibilityResultsJson;

    // Correlation ID for async RabbitMQ reply matching
    @Column(name = "ASYNC_CORRELATION_ID", length = 100)
    private String asyncCorrelationId;

    @Column(name = "CREATED_AT", nullable = false)
    private Instant createdAt;

    @Column(name = "UPDATED_AT")
    private Instant updatedAt;

    @Column(name = "COMPLETED_AT")
    private Instant completedAt;

    @Column(name = "CREATED_BY", length = 100)
    private String createdBy;

    @Column(name = "ERROR_MESSAGE", length = 1000)
    private String errorMessage;

    @Column(name = "RETRY_COUNT")
    private int retryCount = 0;

    @OneToMany(mappedBy = "workflowInstance", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @OrderBy("createdAt ASC")
    private List<WorkflowAuditEvent> auditEvents;

    @PrePersist
    public void prePersist() {
        createdAt = Instant.now();
        updatedAt = Instant.now();
    }

    @PreUpdate
    public void preUpdate() {
        updatedAt = Instant.now();
    }
}
