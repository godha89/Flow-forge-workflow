package com.flowforge.eligibility.drools;

import com.flowforge.eligibility.executor.EligibilityExecutor.CheckOutcome;
import com.flowforge.eligibility.executor.EligibilityExecutor.EligibilityResult;
import com.flowforge.eligibility.registry.EligibilityCheck.WorkflowContext;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.CheckResultStatus;
import com.flowforge.model.enums.OverridePolicy;
import com.flowforge.observability.WorkflowLogger;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * DroolsEligibilityService
 *
 * This is the bridge between your workflow engine and Drools.
 *
 * WHAT IT DOES — in plain English:
 *   1. Takes the applicant data from the workflow context
 *   2. Fills in an EligibilityFact "form" with that data
 *   3. Hands the form to Drools — which runs ALL matching rules against it
 *   4. Reads back the result (PASS / FAIL / REVIEW) that the rules wrote
 *   5. Returns a standard EligibilityResult that the engine understands
 *
 * WHY THIS IS SIMPLER THAN THE OLD WAY:
 *   Old way: Add a new Java class, implement interface, annotate, rebuild
 *   New way: Add 5 lines to a .drl file, restart — done
 */
@Service
@RequiredArgsConstructor
public class DroolsEligibilityService {

    private static final Logger log = LogManager.getLogger(DroolsEligibilityService.class);

    private final KieContainer kieContainer;
    private final WorkflowLogger workflowLogger;

    /**
     * Run all Drools rules against the workflow context.
     *
     * @param definition  The workflow definition (used for param extraction)
     * @param context     The workflow context with applicant data
     * @return            Eligibility result with PASS / FAIL / REVIEW verdict
     */
    public EligibilityResult evaluate(WorkflowDefinition definition, WorkflowContext context) {

        long start = System.currentTimeMillis();
        String instanceId = context.getInstanceId();

        log.info("[{}] Starting Drools eligibility evaluation for workflowType={}",
            instanceId, context.getWorkflowType());

        // Step 1: Build the fact from context data + workflow params
        EligibilityFact fact = buildFact(definition, context);

        // Step 2: Create a Drools session and fire all rules
        KieSession session = kieContainer.newKieSession();
        List<String> firedRules = new ArrayList<>();

        try {
            // Track which rules fired (for audit trail)
            session.addEventListener(new org.kie.api.event.rule.DefaultAgendaEventListener() {
                @Override
                public void afterMatchFired(org.kie.api.event.rule.AfterMatchFiredEvent event) {
                    firedRules.add(event.getMatch().getRule().getName());
                    log.debug("[{}] Rule fired: '{}'", instanceId,
                        event.getMatch().getRule().getName());
                }
            });

            session.insert(fact);
            int rulesFired = session.fireAllRules();

            log.info("[{}] Drools fired {} rule(s): {}", instanceId, rulesFired, firedRules);

        } finally {
            session.dispose();  // always release the session
        }

        long durationMs = System.currentTimeMillis() - start;

        // Step 3: Translate the fact result back to engine format
        return buildResult(fact, firedRules, durationMs, instanceId);
    }

    // ── Build the EligibilityFact from context + workflow params ─────────────

    private EligibilityFact buildFact(WorkflowDefinition definition, WorkflowContext context) {
        EligibilityFact fact = new EligibilityFact();
        Map<String, Object> data = context.getEntityData();

        // Populate from entity data (what the caller submitted)
        fact.setKycStatus(str(data, "kycStatus"));
        fact.setCreditScore(intVal(data, "creditScore"));
        fact.setRiskScore(doubleVal(data, "riskScore"));
        fact.setBalance(doubleVal(data, "balance"));
        fact.setAge(intVal(data, "age"));
        fact.setWorkflowType(context.getWorkflowType());
        fact.setEntityType(context.getEntityType());

        // Also check context data (results from previous process steps)
        if (fact.getCreditScore() == 0) {
            fact.setCreditScore(intVal(context.getContextData(), "credit_score"));
        }
        if (fact.getRiskScore() == 0) {
            fact.setRiskScore(doubleVal(context.getContextData(), "risk_score"));
        }

        // Extract thresholds from workflow definition check params
        // This means rule thresholds stay in MongoDB, not hard-coded in .drl files
        if (definition.getEligibility() != null && definition.getEligibility().getChecks() != null) {
            for (WorkflowDefinition.CheckConfig check : definition.getEligibility().getChecks()) {
                Map<String, Object> params = check.getParams();
                if (params == null) continue;
                switch (check.getCheckId()) {
                    case "CREDIT_SCORE_THRESHOLD" ->
                        fact.setRequiredCreditScore(intVal(params, "min_score"));
                    case "BALANCE_SUFFICIENT" ->
                        fact.setRequiredBalance(doubleVal(params, "min_balance"));
                    case "RISK_SCORE_LOW" ->
                        fact.setMaxRiskScore(doubleVal(params, "threshold"));
                }
            }
        }

        log.debug("[{}] Built EligibilityFact: kyc={} creditScore={} riskScore={} balance={}",
            context.getInstanceId(),
            fact.getKycStatus(), fact.getCreditScore(),
            fact.getRiskScore(), fact.getBalance());

        return fact;
    }

    // ── Translate fact result → EligibilityResult ────────────────────────────

    private EligibilityResult buildResult(EligibilityFact fact,
                                           List<String> firedRules,
                                           long durationMs,
                                           String instanceId) {
        CheckResultStatus status = switch (fact.getResult()) {
            case "FAIL"   -> CheckResultStatus.FAIL;
            case "REVIEW" -> CheckResultStatus.PENDING_REVIEW;
            default       -> CheckResultStatus.PASS;
        };

        OverridePolicy policy = "HARD".equals(fact.getOverridePolicy())
            ? OverridePolicy.HARD : OverridePolicy.SOFT;

        // Build a single outcome representing the Drools evaluation
        CheckOutcome outcome = CheckOutcome.builder()
            .checkId("DROOLS_EVALUATION")
            .checkName("Drools Rules Engine")
            .status(status)
            .reason(fact.getReason())
            .durationMs(durationMs)
            .overridePolicy(policy)
            .metadata(Map.of(
                "firedRule",   fact.getFiredRule() != null ? fact.getFiredRule() : "none",
                "firedRules",  firedRules,
                "kycStatus",   fact.getKycStatus() != null ? fact.getKycStatus() : "",
                "creditScore", fact.getCreditScore(),
                "riskScore",   fact.getRiskScore(),
                "balance",     fact.getBalance()
            ))
            .build();

        boolean eligible     = status == CheckResultStatus.PASS;
        boolean requiresReview = status == CheckResultStatus.PENDING_REVIEW;

        log.info("[{}] Drools result: {} — '{}' ({}ms, rule='{}')",
            instanceId, fact.getResult(), fact.getReason(),
            durationMs, fact.getFiredRule());

        EligibilityResult result = new EligibilityResult();
        result.setInstanceId(instanceId);
        result.setOutcomes(List.of(outcome));
        result.setEligible(eligible);
        result.setRequiresReview(requiresReview);
        return result;
    }

    // ── Type-safe helpers for reading mixed-type maps ─────────────────────────

    private String str(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v != null ? v.toString() : null;
    }

    private int intVal(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (v == null) return 0;
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return 0; }
    }

    private double doubleVal(Map<String, Object> map, String key) {
        Object v = map.get(key);
        if (v == null) return 0.0;
        try { return Double.parseDouble(v.toString()); } catch (Exception e) { return 0.0; }
    }
}
