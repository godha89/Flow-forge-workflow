package com.flowforge.engine.statemachine;

import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.enums.WorkflowStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Enforces legal state transitions for a workflow instance.
 * Transitions are loaded from the WorkflowDefinition config at runtime,
 * with a set of built-in system transitions always allowed.
 */
@Component
public class StateMachine {

    private static final Logger log = LogManager.getLogger(StateMachine.class);

    // Built-in system transitions valid for every workflow type
    private static final Map<WorkflowStatus, List<WorkflowStatus>> SYSTEM_TRANSITIONS = Map.of(
        WorkflowStatus.INITIATED,            List.of(WorkflowStatus.CHECKING_ELIGIBILITY, WorkflowStatus.CANCELLED),
        WorkflowStatus.CHECKING_ELIGIBILITY, List.of(WorkflowStatus.ELIGIBLE, WorkflowStatus.PENDING_REVIEW, WorkflowStatus.REJECTED, WorkflowStatus.FAILED),
        WorkflowStatus.ELIGIBLE,             List.of(WorkflowStatus.PROCESSING, WorkflowStatus.CANCELLED),
        WorkflowStatus.PENDING_REVIEW,       List.of(WorkflowStatus.ELIGIBLE, WorkflowStatus.REJECTED, WorkflowStatus.CANCELLED),
        WorkflowStatus.PROCESSING,           List.of(WorkflowStatus.AWAITING_ASYNC, WorkflowStatus.APPROVED, WorkflowStatus.REJECTED, WorkflowStatus.FAILED),
        WorkflowStatus.AWAITING_ASYNC,       List.of(WorkflowStatus.PROCESSING, WorkflowStatus.FAILED, WorkflowStatus.REJECTED)
    );

    /**
     * Validates whether a transition from → to is permitted.
     * Checks both system-level rules and any workflow-specific overrides.
     */
    public void validateTransition(WorkflowStatus from, WorkflowStatus to,
                                   WorkflowDefinition definition) {
        // Terminal states can never transition out
        if (isTerminal(from)) {
            throw new IllegalStateTransitionException(
                String.format("Cannot transition from terminal status [%s] to [%s]", from, to));
        }

        // Check system-level transitions
        List<WorkflowStatus> allowed = SYSTEM_TRANSITIONS.get(from);
        if (allowed != null && allowed.contains(to)) {
            log.debug("Transition [{} → {}] allowed by system rules", from, to);
            return;
        }

        // Check workflow-definition custom transitions
        if (definition != null && definition.getStatusTransitions() != null) {
            Map<String, List<String>> custom = definition.getStatusTransitions().getTransitions();
            if (custom != null) {
                List<String> customAllowed = custom.get(from.name());
                if (customAllowed != null && customAllowed.contains(to.name())) {
                    log.debug("Transition [{} → {}] allowed by workflow definition", from, to);
                    return;
                }
            }
        }

        throw new IllegalStateTransitionException(
            String.format("Illegal transition [%s → %s] for workflow type [%s]",
                from, to, definition != null ? definition.getWorkflowType() : "unknown"));
    }

    public boolean isTerminal(WorkflowStatus status) {
        return status == WorkflowStatus.APPROVED
            || status == WorkflowStatus.REJECTED
            || status == WorkflowStatus.CANCELLED
            || status == WorkflowStatus.FAILED;
    }

    public static class IllegalStateTransitionException extends RuntimeException {
        public IllegalStateTransitionException(String message) {
            super(message);
        }
    }
}
