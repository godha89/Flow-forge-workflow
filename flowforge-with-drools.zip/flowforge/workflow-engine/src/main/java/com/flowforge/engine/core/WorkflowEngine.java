package com.flowforge.engine.core;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flowforge.eligibility.executor.EligibilityExecutor;
import com.flowforge.eligibility.registry.EligibilityCheck;
import com.flowforge.engine.registry.WorkflowAuditRepository;
import com.flowforge.engine.registry.WorkflowDefinitionRepository;
import com.flowforge.engine.registry.WorkflowInstanceRepository;
import com.flowforge.engine.statemachine.StateMachine;
import com.flowforge.model.domain.WorkflowAuditEvent;
import com.flowforge.model.domain.WorkflowDefinition;
import com.flowforge.model.domain.WorkflowInstance;
import com.flowforge.model.enums.ProcessType;
import com.flowforge.model.enums.WorkflowStatus;
import com.flowforge.observability.WorkflowLogger;
import com.flowforge.process.rabbitmq.RabbitMQProcessExecutor;
import com.flowforge.process.rest.RestProcessExecutor;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

/**
 * Core workflow orchestration engine.
 *
 * Responsibilities:
 *  1. Start a new workflow instance
 *  2. Run eligibility checks
 *  3. Execute process steps (REST sync / RabbitMQ async)
 *  4. Transition state machine
 *  5. Persist every event to the audit trail
 */
@Service
@RequiredArgsConstructor
public class WorkflowEngine {

    private static final Logger log = LogManager.getLogger(WorkflowEngine.class);

    private final WorkflowDefinitionRepository definitionRepository;
    private final WorkflowInstanceRepository instanceRepository;
    private final WorkflowAuditRepository auditRepository;
    private final EligibilityExecutor eligibilityExecutor;
    private final StateMachine stateMachine;
    private final RestProcessExecutor restExecutor;
    private final RabbitMQProcessExecutor rabbitMQExecutor;
    private final WorkflowLogger workflowLogger;
    private final ObjectMapper objectMapper;

    // ── Start Workflow ────────────────────────────────────────────────────────

    @Transactional
    public WorkflowInstance startWorkflow(String workflowType,
                                           String entityId,
                                           String entityType,
                                           Map<String, Object> inputData,
                                           String createdBy) {

        WorkflowDefinition definition = definitionRepository
            .findByWorkflowTypeAndActiveTrue(workflowType)
            .orElseThrow(() -> new IllegalArgumentException(
                "No active workflow definition found for type: " + workflowType));

        WorkflowInstance instance = new WorkflowInstance();
        instance.setWorkflowType(workflowType);
        instance.setWorkflowVersion(definition.getVersion());
        instance.setStatus(WorkflowStatus.INITIATED);
        instance.setEntityId(entityId);
        instance.setEntityType(entityType);
        instance.setCreatedBy(createdBy);

        try {
            Map<String, Object> context = new HashMap<>(inputData);
            instance.setContextJson(objectMapper.writeValueAsString(context));
        } catch (Exception e) {
            instance.setContextJson("{}");
        }

        instanceRepository.save(instance);
        workflowLogger.bind(instance.getId(), workflowType);
        workflowLogger.logWorkflowStart(instance.getId(), workflowType, entityId);

        recordAudit(instance, "WORKFLOW_START", null, WorkflowStatus.INITIATED,
            "Workflow initiated", null, "system");

        // Execute asynchronously so the API call returns immediately
        executeAsync(instance.getId(), definition);

        return instance;
    }

    @Async
    public void executeAsync(String instanceId, WorkflowDefinition definition) {
        try {
            WorkflowInstance instance = instanceRepository.findById(instanceId)
                .orElseThrow(() -> new IllegalStateException("Instance not found: " + instanceId));
            execute(instance, definition);
        } catch (Exception e) {
            log.error("Async execution error for instance {}: {}", instanceId, e.getMessage(), e);
            markFailed(instanceId, e.getMessage());
        }
    }

    // ── Main execution pipeline ───────────────────────────────────────────────

    @Transactional
    public void execute(WorkflowInstance instance, WorkflowDefinition definition) {
        String instanceId = instance.getId();
        long startTime = System.currentTimeMillis();
        workflowLogger.bind(instanceId, instance.getWorkflowType());

        try {
            // 1. ELIGIBILITY PHASE
            transition(instance, WorkflowStatus.CHECKING_ELIGIBILITY, definition);

            Map<String, Object> context = deserializeContext(instance);
            EligibilityCheck.WorkflowContext checkContext = buildCheckContext(instance, context);

            EligibilityExecutor.EligibilityResult eligResult =
                eligibilityExecutor.execute(definition, checkContext);

            // Persist eligibility results
            instance.setEligibilityResultsJson(objectMapper.writeValueAsString(eligResult));

            if (eligResult.isRequiresReview()) {
                transition(instance, WorkflowStatus.PENDING_REVIEW, definition);
                recordAudit(instance, "ELIGIBILITY_PENDING_REVIEW", WorkflowStatus.CHECKING_ELIGIBILITY,
                    WorkflowStatus.PENDING_REVIEW, "Eligibility requires human review", null, "system");
                instanceRepository.save(instance);
                workflowLogger.logWorkflowComplete(instanceId, WorkflowStatus.PENDING_REVIEW,
                    System.currentTimeMillis() - startTime);
                return;
            }

            if (!eligResult.isEligible()) {
                transition(instance, WorkflowStatus.REJECTED, definition);
                recordAudit(instance, "ELIGIBILITY_FAILED", WorkflowStatus.CHECKING_ELIGIBILITY,
                    WorkflowStatus.REJECTED, "Eligibility checks failed", null, "system");
                instance.setCompletedAt(Instant.now());
                instanceRepository.save(instance);
                workflowLogger.logWorkflowComplete(instanceId, WorkflowStatus.REJECTED,
                    System.currentTimeMillis() - startTime);
                return;
            }

            // 2. ELIGIBLE → PROCESSING PHASE
            transition(instance, WorkflowStatus.ELIGIBLE, definition);
            recordAudit(instance, "ELIGIBILITY_PASSED", WorkflowStatus.CHECKING_ELIGIBILITY,
                WorkflowStatus.ELIGIBLE, "All eligibility checks passed", null, "system");

            transition(instance, WorkflowStatus.PROCESSING, definition);
            instanceRepository.save(instance);

            // 3. PROCESS STEPS
            if (definition.getProcesses() != null) {
                boolean suspended = executeProcessSteps(instance, definition, context);
                if (suspended) {
                    // async step — return, will resume via reply listener
                    return;
                }
            }

            // 4. ALL DONE
            transition(instance, WorkflowStatus.APPROVED, definition);
            instance.setCompletedAt(Instant.now());
            instance.setContextJson(objectMapper.writeValueAsString(context));
            instanceRepository.save(instance);

            workflowLogger.logWorkflowComplete(instanceId, WorkflowStatus.APPROVED,
                System.currentTimeMillis() - startTime);
            recordAudit(instance, "WORKFLOW_COMPLETE", WorkflowStatus.PROCESSING,
                WorkflowStatus.APPROVED, "All process steps complete", null, "system");

        } catch (StateMachine.IllegalStateTransitionException ste) {
            log.error("[{}] Illegal state transition: {}", instanceId, ste.getMessage());
            markFailed(instanceId, "State transition error: " + ste.getMessage());
        } catch (Exception ex) {
            workflowLogger.logError(instanceId, "workflow execution", ex);
            markFailed(instanceId, ex.getMessage());
        } finally {
            workflowLogger.unbind();
        }
    }

    // ── Process step executor ─────────────────────────────────────────────────

    private boolean executeProcessSteps(WorkflowInstance instance,
                                         WorkflowDefinition definition,
                                         Map<String, Object> context) throws Exception {
        Set<String> completed = new HashSet<>();

        for (WorkflowDefinition.ProcessStep step : definition.getProcesses()) {
            // Check dependencies
            if (step.getDependsOn() != null && !completed.containsAll(step.getDependsOn())) {
                log.warn("[{}] Step [{}] skipped — dependencies not satisfied: {}",
                    instance.getId(), step.getId(), step.getDependsOn());
                continue;
            }

            instance.setCurrentStep(step.getId());
            instanceRepository.save(instance);

            if (step.getType() == ProcessType.REST) {
                RestProcessExecutor.ProcessResult result =
                    restExecutor.execute(step, instance, context);

                if (result.isSuccess()) {
                    context.putAll(result.getUpdatedContext());
                    completed.add(step.getId());
                    recordAudit(instance, "PROCESS_COMPLETE", null, instance.getStatus(),
                        "REST step completed: " + step.getId(), step.getId(), "system");
                } else {
                    log.error("[{}] REST step [{}] failed: {}", instance.getId(), step.getId(),
                        result.getErrorMessage());
                    markFailed(instance.getId(), "Process step [" + step.getId() + "] failed: "
                        + result.getErrorMessage());
                    return false;
                }

            } else if (step.getType() == ProcessType.RABBITMQ) {
                RabbitMQProcessExecutor.PublishResult pub =
                    rabbitMQExecutor.publish(step, instance, context);

                if (pub.isPublished()) {
                    transition(instance, WorkflowStatus.AWAITING_ASYNC, definition);
                    instance.setAsyncCorrelationId(pub.getCorrelationId());
                    instanceRepository.save(instance);
                    recordAudit(instance, "ASYNC_SUSPENDED", null, WorkflowStatus.AWAITING_ASYNC,
                        "Suspended awaiting RabbitMQ reply: " + pub.getCorrelationId(), step.getId(), "system");
                    return true;  // suspended — stop processing, reply listener will resume
                } else {
                    markFailed(instance.getId(), "RabbitMQ publish failed for step [" + step.getId() + "]: "
                        + pub.getErrorMessage());
                    return false;
                }
            }
        }
        return false;  // all steps done, not suspended
    }

    // ── State helpers ─────────────────────────────────────────────────────────

    private void transition(WorkflowInstance instance, WorkflowStatus to, WorkflowDefinition def) {
        WorkflowStatus from = instance.getStatus();
        stateMachine.validateTransition(from, to, def);
        instance.setStatus(to);
        workflowLogger.logStatusTransition(instance.getId(), from, to);
    }

    @Transactional
    public void markFailed(String instanceId, String reason) {
        instanceRepository.findById(instanceId).ifPresent(inst -> {
            inst.setStatus(WorkflowStatus.FAILED);
            inst.setErrorMessage(reason);
            inst.setCompletedAt(Instant.now());
            instanceRepository.save(inst);
            recordAudit(inst, "WORKFLOW_FAILED", inst.getStatus(), WorkflowStatus.FAILED,
                reason, null, "system");
        });
    }

    // ── Audit ─────────────────────────────────────────────────────────────────

    private void recordAudit(WorkflowInstance instance, String eventType,
                               WorkflowStatus from, WorkflowStatus to,
                               String description, String stepId, String actor) {
        WorkflowAuditEvent event = WorkflowAuditEvent.builder()
            .workflowInstance(instance)
            .eventType(eventType)
            .fromStatus(from != null ? from.name() : null)
            .toStatus(to != null ? to.name() : null)
            .description(description)
            .stepId(stepId)
            .actor(actor)
            .createdAt(Instant.now())
            .build();
        auditRepository.save(event);
    }

    // ── Context helpers ───────────────────────────────────────────────────────

    private Map<String, Object> deserializeContext(WorkflowInstance instance) {
        try {
            String json = instance.getContextJson();
            if (json == null || json.isBlank()) return new HashMap<>();
            return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            log.warn("[{}] Failed to deserialize context: {}", instance.getId(), e.getMessage());
            return new HashMap<>();
        }
    }

    private EligibilityCheck.WorkflowContext buildCheckContext(WorkflowInstance instance,
                                                                Map<String, Object> context) {
        return EligibilityCheck.WorkflowContext.builder()
            .instanceId(instance.getId())
            .workflowType(instance.getWorkflowType())
            .entityId(instance.getEntityId())
            .entityType(instance.getEntityType())
            .entityData(context)
            .contextData(context)
            .inputData(context)
            .build();
    }
}
